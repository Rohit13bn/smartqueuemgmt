import React, { useState, useEffect } from 'react';
import { QueueProvider, useQueue } from './context/QueueContext';
import { Navbar } from './components/layout/Navbar';
import { AuthModal } from './components/auth/AuthModal';
import { ToastContainer } from './components/common/ToastContainer';

import { LandingPage } from './pages/LandingPage';
import { UserDashboardPage } from './pages/UserDashboardPage';
import { TakeTokenPage } from './pages/TakeTokenPage';
import { MyQueuePage } from './pages/MyQueuePage';
import { LiveQueueDisplayPage } from './pages/LiveQueueDisplayPage';
import { AdminDashboardPage } from './pages/AdminDashboardPage';
import { ServiceManagementPage } from './pages/ServiceManagementPage';
import { CounterManagementPage } from './pages/CounterManagementPage';
import { AnalyticsPage } from './pages/AnalyticsPage';
import { ProfileSettingsPage } from './pages/ProfileSettingsPage';

import { Volume2, ArrowRight, X } from 'lucide-react';

function AppContent() {
  const [currentView, setCurrentView] = useState<string>(() => {
    // Read from window.location.hash if available
    const hash = window.location.hash.replace('#/', '').replace('#', '');
    return hash || 'landing';
  });

  const [authModalOpen, setAuthModalOpen] = useState(false);
  const { getUserActiveToken, toasts, dismissToast } = useQueue();

  const activeToken = getUserActiveToken();

  // Sync route with URL hash for easy sharing and navigation
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#/', '').replace('#', '');
      if (hash) {
        setCurrentView(hash);
      }
    };
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const navigateTo = (view: string) => {
    setCurrentView(view);
    window.location.hash = `#/${view}`;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Render current view component
  const renderCurrentPage = () => {
    switch (currentView) {
      case 'landing':
        return <LandingPage onNavigate={navigateTo} onOpenAuth={() => setAuthModalOpen(true)} />;
      case 'user-dashboard':
        return <UserDashboardPage onNavigate={navigateTo} />;
      case 'take-token':
        return <TakeTokenPage onNavigate={navigateTo} />;
      case 'my-queue':
        return <MyQueuePage onNavigate={navigateTo} />;
      case 'live-display':
        return <LiveQueueDisplayPage onNavigate={navigateTo} />;
      case 'admin-dashboard':
        return <AdminDashboardPage onNavigate={navigateTo} onOpenAuth={() => setAuthModalOpen(true)} />;
      case 'service-management':
        return <ServiceManagementPage onNavigate={navigateTo} />;
      case 'counter-management':
        return <CounterManagementPage onNavigate={navigateTo} />;
      case 'analytics':
        return <AnalyticsPage onNavigate={navigateTo} />;
      case 'settings':
        return <ProfileSettingsPage onNavigate={navigateTo} onOpenAuth={() => setAuthModalOpen(true)} />;
      default:
        return <LandingPage onNavigate={navigateTo} onOpenAuth={() => setAuthModalOpen(true)} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col text-slate-900 font-sans">
      
      {/* Top Bar Navigation (Hidden in TV Display Mode) */}
      <Navbar 
        currentView={currentView} 
        onNavigate={navigateTo} 
        onOpenAuth={() => setAuthModalOpen(true)} 
      />

      {/* Floating Global Banner for Called Turn (if user is on other screens) */}
      {activeToken && activeToken.status === 'CALLED' && currentView !== 'my-queue' && currentView !== 'live-display' && (
        <div className="bg-emerald-600 text-white px-4 py-2.5 shadow-md flex items-center justify-between z-30 animate-in slide-in-from-top duration-200">
          <div className="max-w-7xl mx-auto flex-1 flex items-center justify-between gap-4">
            <div className="flex items-center gap-2.5 text-xs">
              <span className="w-2 h-2 rounded-full bg-white animate-ping" />
              <span className="font-bold">YOUR TURN IS BEING CALLED!</span>
              <span className="hidden sm:inline text-emerald-100">
                Token <strong className="text-white font-mono">{activeToken.token_number}</strong> report to {activeToken.counter_number || 'the counter'}.
              </span>
            </div>
            <button
              onClick={() => navigateTo('my-queue')}
              className="px-3 py-1 bg-white text-emerald-800 hover:bg-emerald-50 text-xs font-bold rounded-lg transition-colors flex items-center gap-1 shrink-0"
            >
              <span>View Turn</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Primary Page Canvas */}
      <div className="flex-1">
        {renderCurrentPage()}
      </div>

      {/* Authentication & Role Switcher Modal */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        onSuccess={() => {
          setAuthModalOpen(false);
        }}
      />

      {/* Global Toast Notifications */}
      <ToastContainer toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
}

export default function App() {
  return (
    <QueueProvider>
      <AppContent />
    </QueueProvider>
  );
}
