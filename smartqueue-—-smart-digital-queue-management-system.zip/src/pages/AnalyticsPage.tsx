import React, { useState, useMemo } from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  Users, 
  Calendar, 
  Download, 
  Layers, 
  ArrowUpRight,
  Zap,
  Activity,
  Filter,
  Flame,
  AlertTriangle,
  Monitor
} from 'lucide-react';
import { useQueue } from '../context/QueueContext';
import { DashboardLayout } from '../components/layout/DashboardLayout';
import { Button, Card, StatCard, Badge, Tabs } from '../components/ui';

interface AnalyticsPageProps {
  onNavigate: (view: string) => void;
}

export const AnalyticsPage: React.FC<AnalyticsPageProps> = ({ onNavigate }) => {
  const { tokens, services, counters, getMetrics, showToast } = useQueue();
  const metrics = getMetrics();

  // Filters
  const [dateFilter, setDateFilter] = useState<'today' | '7days' | '30days'>('7days');
  const [serviceFilter, setServiceFilter] = useState<string>('ALL');
  const [counterFilter, setCounterFilter] = useState<string>('ALL');

  // Filtered tokens based on service and counter
  const filteredTokens = useMemo(() => {
    return tokens.filter(t => {
      if (serviceFilter !== 'ALL' && t.service_id !== serviceFilter) return false;
      if (counterFilter !== 'ALL' && t.counter_id !== counterFilter) return false;
      return true;
    });
  }, [tokens, serviceFilter, counterFilter]);

  // Calculations
  const completedTokens = filteredTokens.filter(t => t.status === 'COMPLETED');
  const skippedTokens = filteredTokens.filter(t => t.status === 'SKIPPED');
  const cancelledTokens = filteredTokens.filter(t => t.status === 'CANCELLED');
  const waitingTokens = filteredTokens.filter(t => t.status === 'WAITING');
  const servingTokens = filteredTokens.filter(t => t.status === 'SERVING' || t.status === 'CALLED');

  const totalEvaluated = Math.max(1, filteredTokens.length);
  const completionRate = Math.round((completedTokens.length / totalEvaluated) * 100);
  const skippedRate = Math.round((skippedTokens.length / totalEvaluated) * 100);
  const cancellationRate = Math.round((cancelledTokens.length / totalEvaluated) * 100);

  // Calculate busiest service
  const serviceVolumeMap: Record<string, number> = {};
  tokens.forEach(t => {
    serviceVolumeMap[t.service_id] = (serviceVolumeMap[t.service_id] || 0) + 1;
  });
  let busiestServiceId = services[0]?.id;
  let maxSrvCount = 0;
  Object.entries(serviceVolumeMap).forEach(([sId, count]) => {
    if (count > maxSrvCount) {
      maxSrvCount = count;
      busiestServiceId = sId;
    }
  });
  const busiestService = services.find(s => s.id === busiestServiceId);

  // Hourly traffic distribution
  const hourlyData = [
    { hour: '08:00 AM', volume: 14, waitMin: 4 },
    { hour: '09:00 AM', volume: 38, waitMin: 8 },
    { hour: '10:00 AM', volume: 64, waitMin: 14 },
    { hour: '11:00 AM', volume: 82, waitMin: 22 }, // Peak congestion hour
    { hour: '12:00 PM', volume: 52, waitMin: 12 },
    { hour: '01:00 PM', volume: 30, waitMin: 6 },
    { hour: '02:00 PM', volume: 68, waitMin: 16 },
    { hour: '03:00 PM', volume: 46, waitMin: 10 },
    { hour: '04:00 PM', volume: 20, waitMin: 5 },
  ];

  const maxHourlyVolume = Math.max(...hourlyData.map(h => h.volume));

  // Counter throughput performance
  const counterPerformance = counters.map(c => {
    const servedByCounter = tokens.filter(t => t.counter_id === c.id && t.status === 'COMPLETED').length;
    return {
      counter: c,
      servedCount: servedByCounter,
      efficiencyPct: Math.min(100, Math.max(65, 80 + servedByCounter * 5)),
      avgSpeedMin: Math.max(4, 8 - (servedByCounter % 3)),
    };
  });

  // Export CSV
  const handleExportCSV = () => {
    const csvContent = "data:text/csv;charset=utf-8," + 
      "Token Number,Service,User,Status,Created At,Called At,Completed At\n" +
      filteredTokens.map(t => {
        const s = services.find(srv => srv.id === t.service_id)?.name || '';
        return `"${t.token_number}","${s}","${t.user_name}","${t.status}","${t.created_at}","${t.called_at || ''}","${t.completed_at || ''}"`;
      }).join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `smartqueue_audit_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Audit CSV exported successfully', 'success');
  };

  return (
    <DashboardLayout
      currentView="analytics"
      onNavigate={onNavigate}
      title="Queue Intelligence & Analytics"
      subtitle="Quantitative performance audit, desk velocity metrics, and peak congestion analytics"
      isAdminMode={true}
      action={
        <Button
          variant="outline"
          size="sm"
          onClick={handleExportCSV}
          leftIcon={<Download className="w-3.5 h-3.5 text-slate-500" />}
        >
          Export Audit CSV
        </Button>
      }
    >
      <div className="space-y-6">

        {/* Filter Controls Bar */}
        <Card padding="sm" className="flex flex-wrap items-center justify-between gap-4">
          {/* Date Segment */}
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl">
            <button
              onClick={() => setDateFilter('today')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                dateFilter === 'today' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Today
            </button>
            <button
              onClick={() => setDateFilter('7days')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                dateFilter === '7days' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Last 7 Days
            </button>
            <button
              onClick={() => setDateFilter('30days')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                dateFilter === '30days' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Last 30 Days
            </button>
          </div>

          {/* Service & Counter Selectors */}
          <div className="flex items-center gap-2.5">
            <select
              value={serviceFilter}
              onChange={(e) => setServiceFilter(e.target.value)}
              className="px-3 py-1.5 text-xs rounded-xl border border-slate-300 bg-white text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-600"
            >
              <option value="ALL">All Departments</option>
              {services.map(s => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>

            <select
              value={counterFilter}
              onChange={(e) => setCounterFilter(e.target.value)}
              className="px-3 py-1.5 text-xs rounded-xl border border-slate-300 bg-white text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-600"
            >
              <option value="ALL">All Counters</option>
              {counters.map(c => (
                <option key={c.id} value={c.id}>{c.counter_number}</option>
              ))}
            </select>
          </div>
        </Card>

        {/* 1. TOP SMART INSIGHTS STAT CARDS */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="Completion Rate"
            value={`${completionRate}%`}
            subtitle="Tickets resolved"
            variant="success"
            icon={<CheckCircle2 className="w-4 h-4" />}
          />

          <StatCard
            title="Busiest Department"
            value={busiestService?.name?.slice(0, 15) || 'Student Sec.'}
            subtitle={`${maxSrvCount} active requests`}
            variant="brand"
            icon={<Flame className="w-4 h-4" />}
          />

          <StatCard
            title="Peak Traffic Window"
            value="11:00 AM"
            subtitle="82 tokens / hour"
            variant="warning"
            icon={<Clock className="w-4 h-4" />}
          />

          <StatCard
            title="Dropout / Skip Rate"
            value={`${skippedRate + cancellationRate}%`}
            subtitle="Skipped or cancelled"
            variant="default"
            icon={<AlertTriangle className="w-4 h-4" />}
          />
        </div>

        {/* 2. HOURLY TRAFFIC & CONGESTION CHART */}
        <Card padding="md">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-6">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Hourly Queue Congestion & Velocity</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Ticket volume distribution and corresponding wait times across business hours
              </p>
            </div>
            <span className="text-xs font-mono text-slate-400">Peak: 11:00 AM</span>
          </div>

          {/* Clean Readable Bar Chart */}
          <div className="space-y-4">
            <div className="grid grid-cols-9 gap-2 sm:gap-4 items-end h-48 pt-6 pb-2">
              {hourlyData.map(item => {
                const heightPct = Math.round((item.volume / maxHourlyVolume) * 100);
                const isPeak = item.volume === maxHourlyVolume;

                return (
                  <div key={item.hour} className="flex flex-col items-center h-full justify-end group">
                    <span className="text-[10px] font-mono font-bold text-slate-500 mb-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      {item.volume}
                    </span>
                    <div 
                      className={`w-full rounded-t-lg transition-all duration-300 ${
                        isPeak 
                          ? 'bg-blue-600 hover:bg-blue-700 shadow-xs' 
                          : 'bg-slate-200 hover:bg-slate-300'
                      }`}
                      style={{ height: `${heightPct}%` }}
                    />
                    <span className="text-[10px] text-slate-500 font-mono mt-2 truncate w-full text-center">
                      {item.hour.split(' ')[0]}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </Card>

        {/* 3. COUNTER DESK EFFICIENCY COMPARISON */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card padding="none">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Counter Throughput & Speed</h3>
                <p className="text-xs text-slate-500 mt-0.5">Staff performance and average handling duration</p>
              </div>
              <span className="text-xs font-mono text-slate-400">{counters.length} desks</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-400 uppercase font-mono text-[10px] border-b border-slate-100">
                  <tr>
                    <th className="px-5 py-3">Counter</th>
                    <th className="px-5 py-3">Staff Officer</th>
                    <th className="px-5 py-3">Tickets Served</th>
                    <th className="px-5 py-3">Avg Pace</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {counterPerformance.map(cp => (
                    <tr key={cp.counter.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-5 py-3.5 font-bold font-mono text-slate-900">
                        {cp.counter.counter_number}
                      </td>
                      <td className="px-5 py-3.5 text-slate-700">
                        {cp.counter.staff_name}
                      </td>
                      <td className="px-5 py-3.5 font-mono text-slate-900 font-bold">
                        {cp.servedCount} resolved
                      </td>
                      <td className="px-5 py-3.5 font-mono text-blue-600">
                        ~{cp.avgSpeedMin} min/ticket
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>

          {/* Department Load Distribution */}
          <Card padding="none">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Department Volume Load</h3>
                <p className="text-xs text-slate-500 mt-0.5">Active tickets generated per service catalog item</p>
              </div>
              <span className="text-xs font-mono text-slate-400">{services.length} services</span>
            </div>

            <div className="p-5 space-y-4">
              {services.map(srv => {
                const srvCount = tokens.filter(t => t.service_id === srv.id).length;
                const pct = Math.round((srvCount / Math.max(1, tokens.length)) * 100);

                return (
                  <div key={srv.id} className="space-y-1.5 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-slate-800">{srv.name}</span>
                      <span className="font-mono text-slate-500">{srvCount} tokens ({pct}%)</span>
                    </div>
                    <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                      <div 
                        className="h-full rounded-full bg-blue-600 transition-all duration-300"
                        style={{ width: `${Math.max(8, pct)}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>
        </div>

      </div>
    </DashboardLayout>
  );
};
