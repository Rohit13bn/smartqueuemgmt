import React, { useState, useEffect } from 'react';
import { 
  Clock, 
  Ticket, 
  Tv, 
  Volume2, 
  VolumeX, 
  AlertCircle, 
  CheckCircle2, 
  ArrowRight, 
  Share2,
  Copy,
  Users,
  Compass,
  Sparkles,
  PhoneCall,
  Check,
  Building2,
  RefreshCw,
  AlertTriangle
} from 'lucide-react';
import { useQueue } from '../context/QueueContext';
import { DashboardLayout } from '../components/layout/DashboardLayout';
import { Button, Card, StatusBadge, ConfirmationDialog, ProgressBar } from '../components/ui';
import { chimeSynthesizer } from '../utils/audioChime';

interface MyQueuePageProps {
  onNavigate: (view: string) => void;
}

export const MyQueuePage: React.FC<MyQueuePageProps> = ({ onNavigate }) => {
  const { 
    currentUser, 
    getUserActiveToken, 
    services, 
    counters, 
    getPeopleAhead, 
    getEstimatedWait,
    getCurrentServingTokenForService,
    cancelToken,
    soundEnabled,
    toggleSound,
    showToast
  } = useQueue();

  const [confirmCancelOpen, setConfirmCancelOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  const [isRefreshing, setIsRefreshing] = useState(false);

  const activeToken = getUserActiveToken();
  const service = activeToken ? services.find(s => s.id === activeToken.service_id) : null;
  const currentServing = service ? getCurrentServingTokenForService(service.id) : null;
  const peopleAhead = activeToken ? getPeopleAhead(activeToken.id) : 0;
  const estWait = activeToken ? getEstimatedWait(activeToken.id) : 0;
  const position = peopleAhead + 1;

  // Assigned counter information
  const assignedCounter = activeToken?.counter_id ? counters.find(c => c.id === activeToken.counter_id) : null;

  // Calculate approximate call time
  const approximateCallTime = new Date(Date.now() + estWait * 60 * 1000).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit'
  });

  // Handle manual refresh state
  const handleRefresh = () => {
    setIsRefreshing(true);
    setLastUpdated(new Date());
    setTimeout(() => {
      setIsRefreshing(false);
      showToast('Queue status synchronized with central dispatcher', 'info');
    }, 400);
  };

  const handleCopyToken = () => {
    if (!activeToken) return;
    navigator.clipboard.writeText(activeToken.token_number);
    setCopied(true);
    showToast(`Token ${activeToken.token_number} copied!`, 'success');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShareToken = async () => {
    if (!activeToken) return;
    const shareData = {
      title: `SmartQueue Token ${activeToken.token_number}`,
      text: `Tracking my turn for ${service?.name || 'Department'}. Token: ${activeToken.token_number}. People ahead: ${peopleAhead}.`,
      url: window.location.href,
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch (err) {
        handleCopyToken();
      }
    } else {
      handleCopyToken();
    }
  };

  const handleTestChime = () => {
    chimeSynthesizer.playCalledDing();
    showToast('Subtle chime audio played successfully', 'info');
  };

  return (
    <DashboardLayout
      currentView="my-queue"
      onNavigate={onNavigate}
      title="Live Queue Monitor"
      subtitle="Real-time proximity alerts, turn dispatcher, and audio chimes"
      action={
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={handleRefresh}
            isLoading={isRefreshing}
            leftIcon={<RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />}
          >
            Refresh
          </Button>

          <Button
            size="sm"
            variant="outline"
            onClick={handleTestChime}
            leftIcon={<Volume2 className="w-3.5 h-3.5 text-blue-600" />}
          >
            Test Chime
          </Button>
        </div>
      }
    >
      <div className="space-y-6 max-w-4xl mx-auto">

        {activeToken ? (
          <div className="space-y-6">

            {/* 1. TURN CALLED PROMINENT ALERT (When Status is 'CALLED') */}
            {activeToken.status === 'CALLED' && (
              <div className="p-8 rounded-2xl bg-emerald-600 text-white shadow-xl relative overflow-hidden animate-in fade-in zoom-in-95 duration-200">
                <div className="relative z-10 flex flex-col md:flex-row md:items-center md:justify-between gap-6">
                  <div className="space-y-2">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-700/80 text-emerald-100 text-xs font-bold">
                      <span className="w-2.5 h-2.5 rounded-full bg-white animate-ping" />
                      <span>YOUR TURN IS BEING CALLED RIGHT NOW!</span>
                    </div>
                    <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight">
                      Please Proceed to {activeToken.counter_number || 'Counter 01'}
                    </h2>
                    <p className="text-sm text-emerald-100 max-w-xl leading-relaxed">
                      Officer <strong className="text-white">{assignedCounter?.staff_name || 'Desk Officer'}</strong> is waiting for you. Please bring your credentials and proceed to the counter immediately.
                    </p>
                  </div>

                  <div className="p-6 bg-white rounded-2xl text-slate-900 text-center shadow-lg shrink-0">
                    <span className="text-[11px] font-bold text-slate-400 uppercase tracking-widest block">
                      Token Dispatched
                    </span>
                    <span className="text-4xl sm:text-5xl font-extrabold font-mono text-emerald-600">
                      {activeToken.token_number}
                    </span>
                    <div className="mt-2 text-xs font-bold text-slate-900">
                      {activeToken.counter_number || 'Counter 01'}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 2. PROXIMITY ALERT (When 1-2 people ahead) */}
            {activeToken.status === 'WAITING' && peopleAhead <= 2 && (
              <div className="p-5 rounded-2xl bg-amber-500 text-white shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-amber-600/90 flex items-center justify-center font-bold text-lg shrink-0">
                    <AlertTriangle className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold">Your Turn is Approaching!</h3>
                    <p className="text-xs text-amber-100 mt-0.5">
                      Only <strong className="text-white underline">{peopleAhead} {peopleAhead === 1 ? 'person is' : 'people are'}</strong> ahead in {service?.name}. Please head to the counter area.
                    </p>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-[11px] text-amber-100 block">Est. Time Remaining</span>
                  <span className="text-2xl font-bold font-mono text-white">~{estWait} min</span>
                </div>
              </div>
            )}

            {/* 3. INTERACTIVE QUEUE STATUS CARD (Core Hero Visual) */}
            <Card padding="none" className="overflow-hidden border border-slate-200/90 shadow-sm">
              
              {/* Header */}
              <div className="p-6 bg-slate-900 text-white flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 text-xs font-semibold text-blue-400">
                    <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
                    <span>LIVE QUEUE TRACKER</span>
                    <span className="text-slate-500">·</span>
                    <span className="text-slate-300">{service?.name}</span>
                  </div>
                  <h3 className="text-xl font-bold text-white mt-1">
                    {service?.name}
                  </h3>
                  <span className="text-xs text-slate-400">Department: {service?.department}</span>
                </div>

                <div className="flex items-center gap-2.5">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => onNavigate('live-display')}
                    className="bg-slate-800 text-white border-slate-700 hover:bg-slate-700"
                    leftIcon={<Tv className="w-3.5 h-3.5" />}
                  >
                    View Live Board
                  </Button>
                  <Button
                    size="sm"
                    variant="danger"
                    onClick={() => setConfirmCancelOpen(true)}
                    className="bg-rose-500/10 text-rose-300 hover:bg-rose-500/20 border-rose-500/20"
                  >
                    Cancel Token
                  </Button>
                </div>
              </div>

              {/* Big Token Number & People Ahead Focus Section */}
              <div className="p-8 text-center bg-white border-b border-slate-100 space-y-3">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-widest block">
                  Your Digital Token
                </span>

                <div className="text-6xl sm:text-7xl font-extrabold font-mono text-blue-600 tracking-tight">
                  {activeToken.token_number}
                </div>

                <div className="flex flex-wrap items-center justify-center gap-3 pt-1">
                  <span className="text-base font-bold text-slate-900 font-mono">
                    {peopleAhead} {peopleAhead === 1 ? 'person' : 'people'} ahead of you
                  </span>
                  <span className="text-slate-300">·</span>
                  <span className="text-base font-bold text-emerald-600 font-mono">
                    Estimated wait: {estWait} minutes
                  </span>
                </div>

                <div className="pt-2">
                  <StatusBadge status={activeToken.status} />
                </div>
              </div>

              {/* Detailed Real-Time Metadata Grid */}
              <div className="p-6 grid grid-cols-2 md:grid-cols-4 gap-4 bg-slate-50/60 border-b border-slate-100 text-xs">
                
                <div className="p-3.5 rounded-xl bg-white border border-slate-200/80">
                  <span className="text-slate-400 block text-[11px]">Current Position</span>
                  <span className="font-bold font-mono text-slate-900 text-lg mt-0.5 block">
                    #{position} in line
                  </span>
                </div>

                <div className="p-3.5 rounded-xl bg-white border border-slate-200/80">
                  <span className="text-slate-400 block text-[11px]">Currently Serving</span>
                  <span className="font-bold font-mono text-slate-900 text-lg mt-0.5 block">
                    {currentServing ? currentServing.token_number : 'A-024'}
                  </span>
                </div>

                <div className="p-3.5 rounded-xl bg-white border border-slate-200/80">
                  <span className="text-slate-400 block text-[11px]">Assigned Counter</span>
                  <span className="font-bold text-slate-900 text-base mt-0.5 block">
                    {activeToken.counter_number || 'Dispatch On Call'}
                  </span>
                </div>

                <div className="p-3.5 rounded-xl bg-white border border-slate-200/80">
                  <span className="text-slate-400 block text-[11px]">Approximate Call Time</span>
                  <span className="font-bold font-mono text-blue-600 text-lg mt-0.5 block">
                    {approximateCallTime}
                  </span>
                </div>

              </div>

              {/* Interactive Queue Distance Bar */}
              <div className="p-6 space-y-4">
                <div className="flex items-center justify-between text-xs text-slate-600">
                  <span className="font-bold text-slate-900">Queue Distance Indicator</span>
                  <span className="font-mono text-slate-500">
                    Last updated: {lastUpdated.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                  </span>
                </div>

                {/* Progress bar */}
                <ProgressBar
                  value={Math.max(10, Math.min(100, Math.round(((8 - position) / 8) * 100)))}
                  color={peopleAhead <= 2 ? 'warning' : 'brand'}
                />

                <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
                  <span>Entry: Token Issued</span>
                  <span>Approaching (2 ahead)</span>
                  <span>Counter Dispatch</span>
                </div>
              </div>

              {/* Share & Action Footer */}
              <div className="p-4 bg-slate-50 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleCopyToken}
                    leftIcon={copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  >
                    {copied ? 'Copied' : 'Copy Token'}
                  </Button>

                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleShareToken}
                    leftIcon={<Share2 className="w-3.5 h-3.5" />}
                  >
                    Share Token
                  </Button>
                </div>

                <div className="flex items-center gap-2 text-slate-500">
                  <Volume2 className={`w-3.5 h-3.5 ${soundEnabled ? 'text-blue-600' : 'text-slate-400'}`} />
                  <span>Audio chime: {soundEnabled ? 'Active' : 'Muted'}</span>
                </div>
              </div>

            </Card>

            {/* Helpful Queue Instructions */}
            <div className="p-4 rounded-xl bg-blue-50/70 border border-blue-100 text-xs text-blue-900 flex items-start gap-3">
              <Sparkles className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
              <div className="leading-relaxed">
                <strong>Campus Queue Advice:</strong> You do not need to stand outside the counter room. You can study in the cafeteria or library. SmartQueue will play an audible announcement and display a banner alert as soon as your turn arrives.
              </div>
            </div>

          </div>
        ) : (
          <Card padding="lg" className="text-center py-16">
            <div className="max-w-md mx-auto space-y-4">
              <div className="w-14 h-14 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto">
                <Clock className="w-7 h-7" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900">No Active Queue Token Selected</h3>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  You are not currently monitoring an active queue ticket. Take a digital token from the service catalog to activate real-time turn monitoring.
                </p>
              </div>
              <Button
                variant="primary"
                onClick={() => onNavigate('take-token')}
                leftIcon={<Ticket className="w-4 h-4" />}
                className="mt-2"
              >
                Take a Digital Token
              </Button>
            </div>
          </Card>
        )}

      </div>

      {/* Confirmation Dialog for Cancelling Active Token */}
      {activeToken && (
        <ConfirmationDialog
          isOpen={confirmCancelOpen}
          title="Cancel Active Token?"
          message={`Are you sure you want to cancel token ${activeToken.token_number}? You will forfeit your position in the queue.`}
          confirmLabel="Yes, Cancel Token"
          cancelLabel="Keep Token"
          isDestructive={true}
          onConfirm={() => {
            cancelToken(activeToken.id);
            setConfirmCancelOpen(false);
            showToast(`Token ${activeToken.token_number} cancelled.`, 'info');
          }}
          onCancel={() => setConfirmCancelOpen(false)}
        />
      )}
    </DashboardLayout>
  );
};
