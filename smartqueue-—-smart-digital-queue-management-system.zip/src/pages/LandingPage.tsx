import React, { useState } from 'react';
import { 
  Ticket, 
  Tv, 
  Clock, 
  Bell, 
  Layers, 
  BarChart3, 
  ArrowRight, 
  CheckCircle2, 
  Users, 
  Monitor, 
  ChevronRight, 
  ShieldCheck, 
  Building2, 
  HelpCircle, 
  Check, 
  Volume2, 
  Sparkles,
  Smartphone,
  ChevronDown,
  GraduationCap,
  CreditCard,
  FileText,
  UserCheck,
  Award
} from 'lucide-react';
import { useQueue } from '../context/QueueContext';
import { Button, Card, Badge } from '../components/ui';

interface LandingPageProps {
  onNavigate: (view: string) => void;
  onOpenAuth: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onNavigate, onOpenAuth }) => {
  const { tokens, counters, services, getMetrics } = useQueue();
  const metrics = getMetrics();

  const [activeFaq, setActiveFaq] = useState<number | null>(0);

  // Active serving token
  const currentlyServing = tokens.filter(t => t.status === 'SERVING' || t.status === 'CALLED');
  const leadServing = currentlyServing[0] || tokens.find(t => t.status === 'SERVING') || tokens[0];

  // Up next tokens
  const upNext = tokens.filter(t => t.status === 'WAITING').slice(0, 3);

  const getServiceIcon = (iconName: string) => {
    switch (iconName) {
      case 'GraduationCap': return GraduationCap;
      case 'FileText': return FileText;
      case 'CreditCard': return CreditCard;
      case 'UserCheck': return UserCheck;
      case 'Award': return Award;
      default: return Layers;
    }
  };

  const workflowSteps = [
    {
      step: '01',
      title: 'Choose Service',
      desc: 'Select the department, certificate, or administrative counter you need assistance with.',
      icon: Layers,
    },
    {
      step: '02',
      title: 'Get Digital Token',
      desc: 'Receive an instant queue serial number with real-time wait estimation and digital QR voucher.',
      icon: Ticket,
    },
    {
      step: '03',
      title: 'Track Queue',
      desc: 'Monitor people ahead of you in real-time from your phone or view the campus public monitors.',
      icon: Clock,
    },
    {
      step: '04',
      title: 'Get Notified',
      desc: 'Receive proactive alerts and pleasant chimes when 2 people remain before your turn.',
      icon: Bell,
    },
    {
      step: '05',
      title: 'Visit Counter',
      desc: 'Walk up to the assigned desk immediately when called — zero wasted queue time.',
      icon: Monitor,
    },
  ];

  const faqs = [
    {
      q: 'Do I need an account to take a digital token?',
      a: 'No, you can generate a digital queue token immediately as a student or visitor. Creating a university account enables token history, auto-fill, and persistent device synchronization.'
    },
    {
      q: 'How does SmartQueue calculate estimated waiting time?',
      a: 'Our algorithm multiplies the active waiting count by each specific department’s measured average service duration, dynamically weighted by the number of currently operational counters.'
    },
    {
      q: 'Will I be notified when looking away or on another screen?',
      a: 'Yes. SmartQueue includes Web Audio API audible chimes and proximity notifications that alert you when only two people remain ahead, and triggers a turn call announcement when your token is dispatched.'
    },
    {
      q: 'Can campus administration transfer tokens between departments?',
      a: 'Yes. Administrative staff at counter desks have single-click routing to re-assign or transfer tokens between departments without making students restart the queue.'
    },
    {
      q: 'Can this platform be deployed in hospitals, banks, and government centers?',
      a: 'SmartQueue is purpose-built with versatile architecture suitable for university service centers, clinic triage halls, municipal citizen centers, bank branches, and customer service departments.'
    }
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-between">
      
      {/* 1. HERO SECTION */}
      <section className="relative overflow-hidden pt-12 pb-20 border-b border-slate-200 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left Column: Core Value Proposition */}
            <div className="lg:col-span-7 space-y-6">
              
              {/* Sector Versatility Badges */}
              <div className="flex flex-wrap items-center gap-2 text-xs font-medium text-slate-500">
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-blue-50 text-blue-700 font-semibold border border-blue-200">
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-600 animate-pulse" />
                  Smart Digital Queue Platform
                </span>
                <span className="hidden sm:inline text-slate-400">·</span>
                <span className="text-slate-600">Colleges</span>
                <span className="text-slate-300">·</span>
                <span className="text-slate-600">Service Centers</span>
                <span className="text-slate-300">·</span>
                <span className="text-slate-600">Hospitals</span>
                <span className="text-slate-300">·</span>
                <span className="text-slate-600">Government</span>
              </div>

              {/* Primary Headline */}
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-900 leading-[1.12] text-balance">
                Skip the line. <br />
                <span className="text-blue-600">Track your turn.</span>
              </h1>

              {/* Subtext */}
              <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl">
                Take a digital token, monitor your position in real time, and arrive exactly when it is your turn.
              </p>

              {/* Primary CTAs */}
              <div className="pt-2 flex flex-wrap items-center gap-3">
                <Button
                  size="lg"
                  variant="primary"
                  onClick={() => onNavigate('take-token')}
                  leftIcon={<Ticket className="w-5 h-5" />}
                  className="px-6 py-3 shadow-md shadow-blue-500/20"
                >
                  Take a Token
                </Button>

                <Button
                  size="lg"
                  variant="outline"
                  onClick={() => onNavigate('my-queue')}
                  leftIcon={<Clock className="w-5 h-5 text-slate-500" />}
                  className="px-6 py-3"
                >
                  Track My Queue
                </Button>

                <Button
                  size="lg"
                  variant="ghost"
                  onClick={() => onNavigate('live-display')}
                  leftIcon={<Tv className="w-5 h-5 text-slate-500" />}
                >
                  Live TV Board
                </Button>
              </div>

              {/* Live Application Data Snapshot */}
              <div className="pt-6 border-t border-slate-100 grid grid-cols-3 gap-6 max-w-lg">
                <div>
                  <div className="text-2xl font-bold font-mono text-slate-900 tabular-nums">
                    {metrics.waitingCount + metrics.servingCount}
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">Currently Waiting</div>
                </div>

                <div>
                  <div className="text-2xl font-bold font-mono text-blue-600 tabular-nums">
                    {counters.filter(c => c.status !== 'Offline').length}
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">Active Counters</div>
                </div>

                <div>
                  <div className="text-2xl font-bold font-mono text-emerald-600 tabular-nums">
                    {metrics.avgWaitMinutes} min
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">Avg Response Wait</div>
                </div>
              </div>

            </div>

            {/* Right Column: Live Queue Snapshot Card */}
            <div className="lg:col-span-5">
              <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xl overflow-hidden">
                
                {/* Header */}
                <div className="px-5 py-4 bg-slate-900 text-white flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                    <span className="text-xs font-bold uppercase tracking-wider">Live Queue Dispatch</span>
                  </div>
                  <span className="text-[11px] font-mono text-slate-400">Main Service Counter</span>
                </div>

                {/* Now Calling Spotlight */}
                <div className="p-6 bg-blue-50/60 border-b border-slate-100 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-semibold text-slate-500 uppercase tracking-wide block">
                      Now Calling
                    </span>
                    <span className="text-4xl font-extrabold font-mono text-blue-600 tracking-tight">
                      {leadServing?.token_number || 'A-024'}
                    </span>
                    <div className="text-xs text-slate-600 mt-1 font-medium">
                      {services.find(s => s.id === leadServing?.service_id)?.name || 'Student Section'}
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-xs font-semibold text-slate-500 uppercase tracking-wide block">
                      Proceed To
                    </span>
                    <span className="text-2xl font-extrabold font-mono text-slate-900">
                      {leadServing?.counter_number || 'Counter 01'}
                    </span>
                    <div className="text-xs text-emerald-700 font-semibold mt-1 flex items-center justify-end gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
                      <span>Officer Ready</span>
                    </div>
                  </div>
                </div>

                {/* Up Next List */}
                <div className="p-5">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                      Up Next in Queue
                    </span>
                    <span className="text-xs text-slate-500 font-mono">
                      {metrics.waitingCount} queued
                    </span>
                  </div>

                  <div className="space-y-2">
                    {upNext.map((tok, i) => (
                      <div key={tok.id} className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between text-xs">
                        <div className="flex items-center gap-3">
                          <span className="font-mono text-slate-400 font-bold">#{i + 1}</span>
                          <span className="font-mono font-bold text-slate-900">{tok.token_number}</span>
                          <span className="text-slate-500 truncate max-w-[120px]">{tok.user_name}</span>
                        </div>
                        <span className="text-[11px] text-slate-500 font-mono">
                          ~{tok.estimated_wait_min}m wait
                        </span>
                      </div>
                    ))}
                  </div>

                  <Button
                    variant="outline"
                    size="sm"
                    fullWidth
                    onClick={() => onNavigate('take-token')}
                    className="w-full mt-4"
                  >
                    Join This Queue Now
                  </Button>
                </div>

              </div>
            </div>

          </div>

        </div>
      </section>

      {/* 2. VISUAL WORKFLOW: Choose Service -> Get Token -> Track Queue -> Get Notified -> Visit Counter */}
      <section className="py-20 border-b border-slate-200 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-2xl mx-auto mb-14">
            <h2 className="text-xs font-bold text-blue-600 uppercase tracking-wider mb-2">
              End-to-End Workflow
            </h2>
            <h3 className="text-3xl font-extrabold text-slate-900 tracking-tight text-balance">
              How SmartQueue Works
            </h3>
            <p className="text-sm text-slate-600 mt-2">
              Five frictionless steps from queue entry to desk resolution without standing in lines.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            {workflowSteps.map((wf, idx) => {
              const Icon = wf.icon;
              return (
                <div 
                  key={wf.step}
                  className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs flex flex-col justify-between hover:border-slate-300 transition-all"
                >
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-xs font-mono font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-md border border-blue-100">
                        {wf.step}
                      </span>
                      <div className="w-8 h-8 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center">
                        <Icon className="w-4 h-4" />
                      </div>
                    </div>
                    <h4 className="text-sm font-bold text-slate-900 mb-1.5">{wf.title}</h4>
                    <p className="text-xs text-slate-500 leading-relaxed">{wf.desc}</p>
                  </div>

                  {idx < 4 && (
                    <div className="hidden md:flex justify-end pt-4 text-slate-300">
                      <ChevronRight className="w-4 h-4" />
                    </div>
                  )}
                </div>
              );
            })}
          </div>

        </div>
      </section>

      {/* 3. AVAILABLE SERVICES OVERVIEW (Real Data) */}
      <section className="py-20 border-b border-slate-200 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 mb-12">
            <div>
              <h2 className="text-xs font-bold text-blue-600 uppercase tracking-wider mb-1">
                Desk Directory
              </h2>
              <h3 className="text-3xl font-extrabold text-slate-900 tracking-tight">
                Available Campus Services
              </h3>
              <p className="text-sm text-slate-500 mt-1">
                Real-time queue load and estimated duration across all service counters.
              </p>
            </div>

            <Button
              variant="outline"
              size="sm"
              onClick={() => onNavigate('take-token')}
              rightIcon={<ArrowRight className="w-4 h-4" />}
            >
              Browse All Services
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map(srv => {
              const Icon = getServiceIcon(srv.icon);
              const waiting = tokens.filter(t => t.service_id === srv.id && t.status === 'WAITING').length;
              const estWait = Math.max(2, (waiting + 1) * srv.average_service_time);

              return (
                <Card 
                  key={srv.id} 
                  hoverable 
                  className="flex flex-col justify-between"
                  onClick={() => onNavigate('take-token')}
                >
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
                        <Icon className="w-5 h-5" />
                      </div>
                      <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                        Prefix: {srv.code}
                      </span>
                    </div>

                    <h4 className="text-base font-bold text-slate-900">{srv.name}</h4>
                    <span className="text-xs text-blue-600 font-medium block mt-0.5">{srv.department}</span>
                    <p className="text-xs text-slate-500 mt-2 line-clamp-2 leading-relaxed">
                      {srv.description}
                    </p>
                  </div>

                  <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between text-xs">
                    <div>
                      <span className="text-slate-400 block text-[11px]">Waiting Now</span>
                      <span className="font-bold text-slate-900 font-mono">{waiting} in queue</span>
                    </div>
                    <div className="text-right">
                      <span className="text-slate-400 block text-[11px]">Est. Wait</span>
                      <span className="font-bold text-blue-600 font-mono">~{estWait} min</span>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>

        </div>
      </section>

      {/* 4. PLATFORM BENEFITS & FEATURES */}
      <section className="py-20 border-b border-slate-200 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-2xl mx-auto mb-14">
            <h2 className="text-xs font-bold text-blue-600 uppercase tracking-wider mb-2">
              SaaS Capabilities
            </h2>
            <h3 className="text-3xl font-extrabold text-slate-900 tracking-tight text-balance">
              Designed for High-Volume Service Centers
            </h3>
            <p className="text-sm text-slate-600 mt-2">
              Enterprise features engineered for seamless crowd management and staff productivity.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card padding="lg">
              <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center mb-4">
                <Ticket className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-slate-900 mb-2">Digital Token Lifecycle</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Tokens track from waiting, called, serving, completed, to skipped with complete server-side audit logs.
              </p>
            </Card>

            <Card padding="lg">
              <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center mb-4">
                <Volume2 className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-slate-900 mb-2">Audio Bell Chimes</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Synthesized Web Audio chimes notify users when their turn is called, even when working on another browser tab.
              </p>
            </Card>

            <Card padding="lg">
              <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-600 flex items-center justify-center mb-4">
                <Tv className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-slate-900 mb-2">Broadcast TV Display</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Dedicated high-contrast airport/hall monitor display mode formatted for 1080p, 1440p, 4K and wall TVs.
              </p>
            </Card>

            <Card padding="lg">
              <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center mb-4">
                <Clock className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-slate-900 mb-2">Dynamic Wait Calculation</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Accurate time estimates based on actual active queues and number of desks servicing each department.
              </p>
            </Card>

            <Card padding="lg">
              <div className="w-10 h-10 rounded-xl bg-slate-200 text-slate-800 flex items-center justify-center mb-4">
                <Smartphone className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-slate-900 mb-2">QR Voucher & Mobile Share</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Scan, save, print, or share your digital ticket URL with native Web Share API and clipboard support.
              </p>
            </Card>

            <Card padding="lg">
              <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center mb-4">
                <BarChart3 className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-slate-900 mb-2">Operational Analytics</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Track peak traffic hours, desk service efficiency, completion rates, and export raw logs to CSV.
              </p>
            </Card>
          </div>

        </div>
      </section>

      {/* 5. FREQUENTLY ASKED QUESTIONS */}
      <section className="py-20 border-b border-slate-200 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center mb-12">
            <h2 className="text-xs font-bold text-blue-600 uppercase tracking-wider mb-2">
              Common Questions
            </h2>
            <h3 className="text-3xl font-extrabold text-slate-900 tracking-tight">
              Frequently Asked Questions
            </h3>
          </div>

          <div className="space-y-3">
            {faqs.map((faq, idx) => {
              const isOpen = activeFaq === idx;
              return (
                <div 
                  key={idx}
                  className="rounded-2xl border border-slate-200 overflow-hidden transition-all"
                >
                  <button
                    onClick={() => setActiveFaq(isOpen ? null : idx)}
                    className="w-full p-5 text-left flex items-center justify-between font-bold text-sm text-slate-900 hover:bg-slate-50 transition-colors cursor-pointer"
                  >
                    <span>{faq.q}</span>
                    <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${isOpen ? 'rotate-180 text-blue-600' : ''}`} />
                  </button>

                  {isOpen && (
                    <div className="px-5 pb-5 pt-1 text-xs text-slate-600 leading-relaxed border-t border-slate-100 bg-slate-50/50">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

        </div>
      </section>

      {/* 6. ENTERPRISE FOOTER */}
      <footer className="bg-slate-900 text-slate-300 py-12 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-10 border-b border-slate-800">
            <div className="space-y-3 md:col-span-2">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-blue-600 flex items-center justify-center text-white font-bold">
                  <Layers className="w-4 h-4" />
                </div>
                <span className="text-lg font-bold text-white tracking-tight">SmartQueue</span>
              </div>
              <p className="text-xs text-slate-400 max-w-sm leading-relaxed">
                Smart Digital Queue Management System. Eliminating waiting lines for educational institutions, medical triage, banking hubs, and municipal desks.
              </p>
              <div className="pt-2 text-[11px] text-slate-500 font-mono">
                System Status: <span className="text-emerald-400">All Dispatch Engines Nominal</span>
              </div>
            </div>

            <div>
              <h5 className="text-xs font-bold uppercase tracking-wider text-white mb-3">Navigation</h5>
              <ul className="space-y-2 text-xs">
                <li>
                  <button onClick={() => onNavigate('landing')} className="hover:text-white transition-colors cursor-pointer">
                    Home Portal
                  </button>
                </li>
                <li>
                  <button onClick={() => onNavigate('take-token')} className="hover:text-white transition-colors cursor-pointer">
                    Take Digital Token
                  </button>
                </li>
                <li>
                  <button onClick={() => onNavigate('my-queue')} className="hover:text-white transition-colors cursor-pointer">
                    My Active Turn
                  </button>
                </li>
                <li>
                  <button onClick={() => onNavigate('live-display')} className="hover:text-white transition-colors cursor-pointer">
                    Live TV Board
                  </button>
                </li>
              </ul>
            </div>

            <div>
              <h5 className="text-xs font-bold uppercase tracking-wider text-white mb-3">Operations</h5>
              <ul className="space-y-2 text-xs">
                <li>
                  <button onClick={() => onNavigate('admin-dashboard')} className="hover:text-white transition-colors cursor-pointer">
                    Admin Dispatch Desk
                  </button>
                </li>
                <li>
                  <button onClick={() => onNavigate('counter-management')} className="hover:text-white transition-colors cursor-pointer">
                    Counter Management
                  </button>
                </li>
                <li>
                  <button onClick={() => onNavigate('service-management')} className="hover:text-white transition-colors cursor-pointer">
                    Service Catalog
                  </button>
                </li>
                <li>
                  <button onClick={() => onNavigate('analytics')} className="hover:text-white transition-colors cursor-pointer">
                    Queue Intelligence
                  </button>
                </li>
              </ul>
            </div>
          </div>

          <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-3">
            <span>© {new Date().getFullYear()} SmartQueue Platform. All rights reserved.</span>
            <div className="flex items-center gap-4 text-[11px]">
              <span>ISO 27001 Certified Architecture</span>
              <span>·</span>
              <span>WCAG 2.1 AA Compliant</span>
            </div>
          </div>

        </div>
      </footer>

    </div>
  );
};
