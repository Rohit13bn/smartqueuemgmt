import React, { useState, useEffect } from 'react';
import { 
  Tv, 
  Volume2, 
  VolumeX, 
  Maximize, 
  Minimize, 
  ArrowLeft, 
  Clock, 
  Bell, 
  Layers, 
  Sparkles,
  CheckCircle2,
  Calendar,
  Monitor,
  Activity,
  Users
} from 'lucide-react';
import { useQueue } from '../context/QueueContext';
import { chimeSynthesizer } from '../utils/audioChime';

interface LiveQueueDisplayPageProps {
  onNavigate: (view: string) => void;
}

export const LiveQueueDisplayPage: React.FC<LiveQueueDisplayPageProps> = ({ onNavigate }) => {
  const { 
    tokens, 
    counters, 
    services, 
    lastCalledToken, 
    soundEnabled, 
    toggleSound,
    getMetrics
  } = useQueue();

  const metrics = getMetrics();

  const [currentTime, setCurrentTime] = useState(new Date());
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [selectedServiceFilter, setSelectedServiceFilter] = useState<string>('all');
  const [announcementToken, setAnnouncementToken] = useState<any | null>(null);

  // Live Clock updater
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Flash announcement banner when lastCalledToken updates
  useEffect(() => {
    if (lastCalledToken) {
      setAnnouncementToken(lastCalledToken);
      const timer = setTimeout(() => {
        setAnnouncementToken(null);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [lastCalledToken]);

  // Fullscreen toggle handler
  const handleToggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().catch(() => {});
        setIsFullscreen(false);
      }
    }
  };

  // Filter tokens if specific service selected
  const activeTokens = tokens.filter(t => 
    selectedServiceFilter === 'all' || t.service_id === selectedServiceFilter
  );

  // Serving tokens list
  const servingTokens = activeTokens.filter(t => t.status === 'SERVING' || t.status === 'CALLED');
  const leadServing = lastCalledToken || servingTokens[0] || tokens.find(t => t.status === 'SERVING') || tokens[0];

  // Up next tokens (waiting)
  const upNextTokens = activeTokens.filter(t => t.status === 'WAITING').slice(0, 5);

  // Recently completed tokens
  const recentlyCompleted = activeTokens.filter(t => t.status === 'COMPLETED').slice(-4).reverse();

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col justify-between selection:bg-blue-600 selection:text-white font-sans antialiased">
      
      {/* 1. TOP STATUS BAR (Airport / Hospital Style) */}
      <header className="px-6 py-4 border-b border-slate-800 bg-slate-900/95 backdrop-blur-md flex items-center justify-between z-20">
        
        {/* Left: Exit + Brand + Location */}
        <div className="flex items-center gap-4">
          <button
            onClick={() => onNavigate('landing')}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Exit TV Mode</span>
          </button>

          <div className="h-5 w-px bg-slate-800 hidden sm:block" />

          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center font-bold text-white shadow-lg shadow-blue-500/20">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-base font-extrabold tracking-tight text-white leading-tight">
                SmartQueue Live Board
              </h1>
              <p className="text-[11px] text-slate-400 font-medium">
                Central Campus Hall · Real-Time Desk Dispatch
              </p>
            </div>
          </div>
        </div>

        {/* Center: Service Category Filter (For Multi-service hubs) */}
        <div className="hidden xl:flex items-center gap-1 p-1 bg-slate-800/80 rounded-xl border border-slate-700/50">
          <button
            onClick={() => setSelectedServiceFilter('all')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              selectedServiceFilter === 'all' 
                ? 'bg-blue-600 text-white shadow-xs' 
                : 'text-slate-400 hover:text-white'
            }`}
          >
            All Services
          </button>
          {services.map(s => (
            <button
              key={s.id}
              onClick={() => setSelectedServiceFilter(s.id)}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                selectedServiceFilter === s.id 
                  ? 'bg-blue-600 text-white shadow-xs' 
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {s.name}
            </button>
          ))}
        </div>

        {/* Right: Date, Live Clock, Sound & Fullscreen controls */}
        <div className="flex items-center gap-4 text-xs">
          <div className="text-right hidden sm:block">
            <div className="text-white font-mono font-bold text-sm tracking-wide">
              {currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
            </div>
            <div className="text-slate-400 text-[11px] font-medium">
              {currentTime.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={toggleSound}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer"
              title={soundEnabled ? 'Chime sound active' : 'Chime sound muted'}
              aria-label="Toggle chime sound"
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-blue-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
            </button>

            <button
              onClick={handleToggleFullscreen}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer"
              title={isFullscreen ? 'Exit Fullscreen' : 'Enter Fullscreen'}
              aria-label="Toggle fullscreen display"
            >
              {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
            </button>
          </div>
        </div>

      </header>

      {/* 2. CALL ANNOUNCEMENT OVERLAY BANNER (When token called) */}
      {announcementToken && (
        <div className="bg-emerald-600 text-white px-6 py-4 shadow-2xl border-b border-emerald-500 animate-in slide-in-from-top duration-300 z-30">
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 text-center md:text-left">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-white text-emerald-800 flex items-center justify-center font-black text-xl shadow-md shrink-0">
                <Bell className="w-6 h-6 animate-bounce" />
              </div>
              <div>
                <span className="text-xs font-bold uppercase tracking-widest text-emerald-200">
                  ATTENTION PLEASE
                </span>
                <div className="text-2xl sm:text-3xl font-extrabold tracking-tight">
                  Token <span className="font-mono underline text-white">{announcementToken.token_number}</span> please proceed to {announcementToken.counter_number || 'Counter 01'}
                </div>
              </div>
            </div>

            <div className="px-5 py-2 rounded-xl bg-emerald-700 font-mono font-bold text-sm tracking-wider">
              {services.find(s => s.id === announcementToken.service_id)?.name || 'Service Desk'}
            </div>
          </div>
        </div>
      )}

      {/* 3. MAIN TV STAGE (High-Density Split Layout for Large Monitors) */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        
        {/* Left / Center Major Stage: NOW SERVING (Spotlight Card) */}
        <div className="lg:col-span-8 flex flex-col justify-between">
          
          <div className="bg-slate-900 rounded-3xl border border-slate-800 p-8 sm:p-12 shadow-2xl relative overflow-hidden flex-1 flex flex-col justify-between">
            
            {/* Top Tag */}
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-6">
              <div className="flex items-center gap-3">
                <span className="w-3.5 h-3.5 rounded-full bg-emerald-400 animate-ping" />
                <span className="text-xs sm:text-sm font-extrabold tracking-widest uppercase text-emerald-400">
                  NOW SERVING AT COUNTER
                </span>
              </div>
              <span className="text-xs font-mono text-slate-400 bg-slate-800 px-3 py-1 rounded-lg">
                Primary Call Window
              </span>
            </div>

            {/* Huge Center Numbers */}
            <div className="py-10 text-center space-y-4">
              <div className="text-7xl sm:text-9xl font-black font-mono tracking-tight text-white drop-shadow-md">
                {leadServing?.token_number || 'A-024'}
              </div>

              <div className="inline-block px-5 py-2 rounded-2xl bg-blue-950/80 border border-blue-800 text-blue-300 font-bold text-lg sm:text-xl">
                {services.find(s => s.id === leadServing?.service_id)?.name || 'Student Section'}
              </div>
            </div>

            {/* Bottom Counter Location & Staff Dispatcher */}
            <div className="pt-8 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 bg-slate-950/40 -mx-8 -mb-8 sm:-mx-12 sm:-mb-12 p-8 rounded-b-3xl">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block">
                  Designated Station
                </span>
                <span className="text-3xl sm:text-4xl font-extrabold font-mono text-emerald-400 mt-0.5 block">
                  {leadServing?.counter_number || 'Counter 01'}
                </span>
              </div>

              <div className="text-right">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block">
                  Serving Officer
                </span>
                <span className="text-xl sm:text-2xl font-bold text-white mt-0.5 block">
                  {counters.find(c => c.id === leadServing?.counter_id)?.staff_name || 'Staff Officer'}
                </span>
              </div>
            </div>

          </div>

          {/* Real-Time Operational Counters Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4">
            {counters.slice(0, 4).map(cnt => {
              const currentTok = tokens.find(t => t.id === cnt.current_token_id);
              return (
                <div key={cnt.id} className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800">
                  <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                    <span className="font-bold">{cnt.counter_number}</span>
                    <span className={`w-2 h-2 rounded-full ${cnt.status === 'Available' ? 'bg-emerald-400' : cnt.status === 'Serving' ? 'bg-blue-400' : 'bg-slate-500'}`} />
                  </div>
                  <div className="text-base font-mono font-bold text-white">
                    {currentTok ? currentTok.token_number : cnt.status}
                  </div>
                  <div className="text-[11px] text-slate-500 truncate mt-0.5">
                    {cnt.staff_name}
                  </div>
                </div>
              );
            })}
          </div>

        </div>

        {/* Right Stage: UP NEXT QUEUE & RECENTLY COMPLETED */}
        <div className="lg:col-span-4 flex flex-col justify-between gap-6">
          
          {/* UP NEXT QUEUE LIST */}
          <div className="bg-slate-900 rounded-3xl border border-slate-800 p-6 shadow-xl flex-1 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-4">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-blue-400" />
                  <h2 className="text-xs font-bold uppercase tracking-wider text-white">
                    UP NEXT IN QUEUE
                  </h2>
                </div>
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-blue-950 text-blue-400 border border-blue-900">
                  {metrics.waitingCount} waiting
                </span>
              </div>

              <div className="space-y-3">
                {upNextTokens.length === 0 ? (
                  <div className="py-8 text-center text-xs text-slate-500">
                    No waiting tokens in current queue
                  </div>
                ) : (
                  upNextTokens.map((tok, idx) => {
                    const srv = services.find(s => s.id === tok.service_id);
                    return (
                      <div 
                        key={tok.id} 
                        className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-between"
                      >
                        <div className="flex items-center gap-3">
                          <span className="w-6 h-6 rounded-lg bg-slate-800 text-slate-400 font-mono font-bold text-xs flex items-center justify-center">
                            {idx + 1}
                          </span>
                          <div>
                            <span className="text-lg font-black font-mono text-white block leading-tight">
                              {tok.token_number}
                            </span>
                            <span className="text-[11px] text-slate-400 truncate max-w-[140px] block">
                              {srv?.name}
                            </span>
                          </div>
                        </div>

                        <div className="text-right font-mono text-xs text-blue-400 font-bold">
                          ~{tok.estimated_wait_min}m
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800/80 text-[11px] text-slate-500 flex items-center justify-between">
              <span>Average Service Time</span>
              <span className="font-mono font-bold text-white">~6 minutes</span>
            </div>
          </div>

          {/* RECENTLY COMPLETED TICKETS */}
          <div className="bg-slate-900 rounded-3xl border border-slate-800 p-6 shadow-xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300">
                  RECENTLY RESOLVED
                </h3>
              </div>
              <span className="text-xs font-mono text-slate-400">
                {metrics.servedTodayCount} today
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {recentlyCompleted.map(tok => (
                <div key={tok.id} className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 flex items-center justify-between text-xs">
                  <span className="font-mono font-bold text-slate-300">{tok.token_number}</span>
                  <span className="text-[10px] text-emerald-400 font-bold">DONE ✓</span>
                </div>
              ))}
            </div>
          </div>

        </div>

      </main>

      {/* 4. BOTTOM TELEMETRY BAR */}
      <footer className="px-6 py-3 border-t border-slate-800/80 bg-slate-900/95 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-400 gap-2">
        <div className="flex items-center gap-3">
          <span className="inline-flex items-center gap-1.5 text-emerald-400 font-medium">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>Digital Dispatch Engine Active</span>
          </span>
          <span className="text-slate-600">·</span>
          <span>Central Campus Hub</span>
        </div>

        <div className="flex items-center gap-4 text-[11px] font-mono">
          <span>Served Today: <strong className="text-white">{metrics.servedTodayCount}</strong></span>
          <span>·</span>
          <span>Active Queue: <strong className="text-blue-400">{metrics.waitingCount}</strong></span>
          <span>·</span>
          <span>Open Counters: <strong className="text-emerald-400">{counters.filter(c => c.status !== 'Offline').length}</strong></span>
        </div>
      </footer>

    </div>
  );
};
