import React, { useState } from 'react';
import { 
  User as UserIcon, 
  Volume2, 
  Bell, 
  ShieldCheck, 
  RotateCcw, 
  Check, 
  Smartphone, 
  Mail, 
  Save,
  Sparkles,
  Sliders,
  Eye,
  LogOut,
  Building2,
  Lock,
  Laptop
} from 'lucide-react';
import { useQueue } from '../context/QueueContext';
import { DashboardLayout } from '../components/layout/DashboardLayout';
import { Button, Card, Tabs, ConfirmationDialog } from '../components/ui';
import { chimeSynthesizer } from '../utils/audioChime';

interface ProfileSettingsPageProps {
  onNavigate: (view: string) => void;
  onOpenAuth: () => void;
}

export const ProfileSettingsPage: React.FC<ProfileSettingsPageProps> = ({ onNavigate, onOpenAuth }) => {
  const { 
    currentUser, 
    setCurrentUser, 
    soundEnabled, 
    toggleSound, 
    resetQueue, 
    logout,
    showToast 
  } = useQueue();

  const [activeTab, setActiveTab] = useState<string>('profile');

  // Form states
  const [name, setName] = useState(currentUser.name);
  const [email, setEmail] = useState(currentUser.email);
  const [studentId, setStudentId] = useState(currentUser.studentId || '');
  const [phone, setPhone] = useState(currentUser.phone || '+1 (555) 019-2831');
  const [notifyProximity, setNotifyProximity] = useState(true);
  const [notifyCalled, setNotifyCalled] = useState(true);
  const [compactDensity, setCompactDensity] = useState(false);
  const [highContrast, setHighContrast] = useState(false);
  const [logoutConfirmOpen, setLogoutConfirmOpen] = useState(false);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setCurrentUser({
      ...currentUser,
      name,
      email,
      studentId,
      phone,
    });
    showToast('Profile preferences updated successfully', 'success');
  };

  const handleTestChime = () => {
    chimeSynthesizer.playCallChime();
    showToast('Call chime audio played', 'info');
  };

  const handleTestProximityDing = () => {
    chimeSynthesizer.playApproachingDing();
    showToast('Approaching proximity audio played', 'info');
  };

  const settingsTabs = [
    { id: 'profile', label: 'Identity Profile', icon: <UserIcon className="w-3.5 h-3.5" /> },
    { id: 'sound', label: 'Audio & Cues', icon: <Volume2 className="w-3.5 h-3.5" /> },
    { id: 'notifications', label: 'Alert Preferences', icon: <Bell className="w-3.5 h-3.5" /> },
    { id: 'appearance', label: 'Accessibility', icon: <Sliders className="w-3.5 h-3.5" /> },
    { id: 'session', label: 'Security & Session', icon: <ShieldCheck className="w-3.5 h-3.5" /> },
  ];

  return (
    <DashboardLayout
      currentView="settings"
      onNavigate={onNavigate}
      title="Settings & Preferences"
      subtitle="Configure identity profile, audible cues, notification thresholds, and security preferences"
      isAdminMode={currentUser.role === 'admin'}
    >
      <div className="max-w-4xl space-y-6">

        {/* Tab Navigation */}
        <div className="overflow-x-auto pb-1">
          <Tabs
            items={settingsTabs}
            activeId={activeTab}
            onChange={setActiveTab}
          />
        </div>

        {/* 1. IDENTITY PROFILE */}
        {activeTab === 'profile' && (
          <Card padding="none" className="overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-blue-100 text-blue-700 font-extrabold flex items-center justify-center text-sm shadow-xs">
                  {name.slice(0, 2).toUpperCase()}
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-sm">Account Identity</h3>
                  <p className="text-xs text-slate-500">
                    Role: <strong className="uppercase text-blue-600 font-bold">{currentUser.role === 'admin' ? 'Administrator' : 'Student / Citizen'}</strong>
                  </p>
                </div>
              </div>

              <Button
                variant="outline"
                size="sm"
                onClick={onOpenAuth}
              >
                Switch Account
              </Button>
            </div>

            <form onSubmit={handleSaveProfile} className="p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Full Legal Name
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    University / Corporate Email
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    {currentUser.role === 'admin' ? 'Staff Faculty ID' : 'Student Enrollment ID'}
                  </label>
                  <input
                    type="text"
                    value={studentId}
                    onChange={(e) => setStudentId(e.target.value)}
                    className="w-full px-3 py-2 text-xs font-mono rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Mobile Phone (For SMS Turn Alerts)
                  </label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3 py-2 text-xs font-mono rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end">
                <Button
                  type="submit"
                  variant="primary"
                  size="sm"
                  leftIcon={<Save className="w-3.5 h-3.5" />}
                >
                  Save Profile Changes
                </Button>
              </div>
            </form>
          </Card>
        )}

        {/* 2. AUDIO & CUES */}
        {activeTab === 'sound' && (
          <Card padding="md" className="space-y-6">
            <div>
              <h3 className="text-base font-bold text-slate-900">Web Audio Synthesizer Cues</h3>
              <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">
                Configure pleasant browser chimes that trigger even when viewing other tabs or background applications.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-slate-900 block">Master Sound Effects</span>
                <span className="text-xs text-slate-500">Enable synthesized bell chimes for token announcements</span>
              </div>
              <Button
                size="sm"
                variant={soundEnabled ? 'primary' : 'outline'}
                onClick={toggleSound}
              >
                {soundEnabled ? 'Enabled (Active)' : 'Muted'}
              </Button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-xl border border-slate-200 space-y-3">
                <span className="text-xs font-bold text-slate-800 block">Turn Called Announcement</span>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Dual-tone bell chime played when your token is called by a desk officer.
                </p>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleTestChime}
                  leftIcon={<Volume2 className="w-3.5 h-3.5 text-blue-600" />}
                >
                  Test Call Chime
                </Button>
              </div>

              <div className="p-4 rounded-xl border border-slate-200 space-y-3">
                <span className="text-xs font-bold text-slate-800 block">Proximity Alert Chime</span>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Subtle single-frequency chime played when 2 people remain ahead in queue.
                </p>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleTestProximityDing}
                  leftIcon={<Volume2 className="w-3.5 h-3.5 text-amber-600" />}
                >
                  Test Proximity Ding
                </Button>
              </div>
            </div>
          </Card>
        )}

        {/* 3. NOTIFICATION PREFERENCES */}
        {activeTab === 'notifications' && (
          <Card padding="md" className="space-y-6">
            <div>
              <h3 className="text-base font-bold text-slate-900">Queue Notification Triggers</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Choose when SmartQueue notifies your device.
              </p>
            </div>

            <div className="space-y-3">
              <label className="flex items-center justify-between p-3.5 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer text-xs">
                <div>
                  <span className="font-bold text-slate-900 block">Turn Approaching Warning</span>
                  <span className="text-slate-500">Alert me when only 2 people are ahead of me in the queue</span>
                </div>
                <input
                  type="checkbox"
                  checked={notifyProximity}
                  onChange={(e) => setNotifyProximity(e.target.checked)}
                  className="rounded text-blue-600 h-4 w-4"
                />
              </label>

              <label className="flex items-center justify-between p-3.5 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer text-xs">
                <div>
                  <span className="font-bold text-slate-900 block">Immediate Turn Dispatched</span>
                  <span className="text-slate-500">Trigger banner and sound immediately when counter is assigned</span>
                </div>
                <input
                  type="checkbox"
                  checked={notifyCalled}
                  onChange={(e) => setNotifyCalled(e.target.checked)}
                  className="rounded text-blue-600 h-4 w-4"
                />
              </label>
            </div>
          </Card>
        )}

        {/* 4. APPEARANCE & ACCESSIBILITY */}
        {activeTab === 'appearance' && (
          <Card padding="md" className="space-y-6">
            <div>
              <h3 className="text-base font-bold text-slate-900">Display Density & Accessibility</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Adjust visual spacing and contrast parameters.
              </p>
            </div>

            <div className="space-y-3">
              <label className="flex items-center justify-between p-3.5 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer text-xs">
                <div>
                  <span className="font-bold text-slate-900 block">Compact Table Density</span>
                  <span className="text-slate-500">Use higher-density row spacing for queue operations tables</span>
                </div>
                <input
                  type="checkbox"
                  checked={compactDensity}
                  onChange={(e) => {
                    setCompactDensity(e.target.checked);
                    showToast(e.target.checked ? 'Compact table density enabled' : 'Default density restored', 'info');
                  }}
                  className="rounded text-blue-600 h-4 w-4"
                />
              </label>

              <label className="flex items-center justify-between p-3.5 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer text-xs">
                <div>
                  <span className="font-bold text-slate-900 block">High Contrast Numeric Displays</span>
                  <span className="text-slate-500">Enhance tabular figure weight for outdoor readability</span>
                </div>
                <input
                  type="checkbox"
                  checked={highContrast}
                  onChange={(e) => setHighContrast(e.target.checked)}
                  className="rounded text-blue-600 h-4 w-4"
                />
              </label>
            </div>
          </Card>
        )}

        {/* 5. SECURITY & SESSION */}
        {activeTab === 'session' && (
          <Card padding="md" className="space-y-6">
            <div>
              <h3 className="text-base font-bold text-slate-900">Security & Session Management</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Manage your active browser session and authenticated permissions.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500">Current User:</span>
                <span className="font-bold text-slate-900">{currentUser.name} ({currentUser.email})</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Role Authorization:</span>
                <span className="font-mono uppercase font-bold text-blue-600">{currentUser.role}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Session Environment:</span>
                <span className="font-mono text-slate-700">Production SaaS Sandbox</span>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-slate-900 block">Sign Out of Session</span>
                <span className="text-xs text-slate-500">Clears current auth token from browser memory</span>
              </div>
              <Button
                variant="danger"
                size="sm"
                onClick={() => setLogoutConfirmOpen(true)}
                leftIcon={<LogOut className="w-3.5 h-3.5" />}
              >
                Sign Out
              </Button>
            </div>
          </Card>
        )}

      </div>

      {/* Logout Confirmation Dialog */}
      <ConfirmationDialog
        isOpen={logoutConfirmOpen}
        title="Sign Out of SmartQueue?"
        message="Are you sure you want to end your current session? You will need to sign in again to access your active tickets."
        confirmLabel="Yes, Sign Out"
        cancelLabel="Stay Signed In"
        isDestructive={true}
        onConfirm={() => {
          logout();
          setLogoutConfirmOpen(false);
          onNavigate('landing');
          showToast('Signed out successfully', 'info');
        }}
        onCancel={() => setLogoutConfirmOpen(false)}
      />

    </DashboardLayout>
  );
};
