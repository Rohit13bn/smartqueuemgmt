import React, { useState } from 'react';
import { 
  Monitor, 
  Plus, 
  Edit2, 
  Coffee, 
  PowerOff, 
  CheckCircle2, 
  UserCheck, 
  Sparkles,
  PhoneCall,
  Layers,
  Users,
  AlertTriangle
} from 'lucide-react';
import { useQueue } from '../context/QueueContext';
import { DashboardLayout } from '../components/layout/DashboardLayout';
import { Counter, CounterStatus } from '../types';
import { Button, Card, Modal, StatusBadge } from '../components/ui';

interface CounterManagementPageProps {
  onNavigate: (view: string) => void;
}

export const CounterManagementPage: React.FC<CounterManagementPageProps> = ({ onNavigate }) => {
  const { counters, services, addCounter, updateCounter, updateCounterStatus, tokens, showToast } = useQueue();

  const [modalOpen, setModalOpen] = useState(false);
  const [editingCounter, setEditingCounter] = useState<Counter | null>(null);

  // Form states
  const [counterNumber, setCounterNumber] = useState('');
  const [staffName, setStaffName] = useState('');
  const [assignedServiceIds, setAssignedServiceIds] = useState<string[]>([]);
  const [status, setStatus] = useState<CounterStatus>('Available');

  const handleOpenAdd = () => {
    setEditingCounter(null);
    setCounterNumber(`Counter 0${counters.length + 1}`);
    setStaffName('');
    setAssignedServiceIds([services[0]?.id || '']);
    setStatus('Available');
    setModalOpen(true);
  };

  const handleOpenEdit = (c: Counter) => {
    setEditingCounter(c);
    setCounterNumber(c.counter_number);
    setStaffName(c.staff_name);
    setAssignedServiceIds(c.assigned_service_ids);
    setStatus(c.status);
    setModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!counterNumber.trim() || !staffName.trim()) return;

    if (editingCounter) {
      updateCounter(editingCounter.id, {
        counter_number: counterNumber.trim(),
        staff_name: staffName.trim(),
        assigned_service_ids: assignedServiceIds,
        status,
      });
      showToast(`Counter ${counterNumber} updated`, 'success');
    } else {
      addCounter({
        counter_number: counterNumber.trim(),
        staff_name: staffName.trim(),
        assigned_service_ids: assignedServiceIds,
        status,
      });
      showToast(`Counter ${counterNumber} added`, 'success');
    }

    setModalOpen(false);
  };

  const toggleServiceAssignment = (srvId: string) => {
    setAssignedServiceIds(prev => 
      prev.includes(srvId)
        ? prev.filter(id => id !== srvId)
        : [...prev, srvId]
    );
  };

  return (
    <DashboardLayout
      currentView="counter-management"
      onNavigate={onNavigate}
      title="Counter & Desk Management"
      subtitle="Manage physical reception desks, assigned staff members, operational statuses, and live desk queues"
      isAdminMode={true}
      action={
        <Button
          variant="primary"
          size="sm"
          onClick={handleOpenAdd}
          leftIcon={<Plus className="w-3.5 h-3.5" />}
        >
          Add New Counter
        </Button>
      }
    >
      <div className="space-y-6">

        {/* Counter Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {counters.map(counter => {
            const currentToken = tokens.find(t => t.id === counter.current_token_id);
            const assignedServices = services.filter(s => counter.assigned_service_ids.includes(s.id));
            
            // Queue length waiting for services handled by this counter
            const queueLength = tokens.filter(t => 
              t.status === 'WAITING' && counter.assigned_service_ids.includes(t.service_id)
            ).length;

            const isOverloaded = queueLength >= 5;

            return (
              <Card
                key={counter.id}
                className="flex flex-col justify-between"
              >
                <div>
                  {/* Top Bar of Counter Card */}
                  <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-bold text-sm text-slate-900">{counter.counter_number}</h3>
                        {isOverloaded && (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200">
                            High Load
                          </span>
                        )}
                      </div>
                      <span className="text-xs text-slate-500">Staff Officer: <strong className="text-slate-800">{counter.staff_name}</strong></span>
                    </div>

                    <button
                      onClick={() => handleOpenEdit(counter)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-blue-600 hover:bg-slate-50 transition-colors cursor-pointer"
                      title="Edit Counter"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Operational Status Switcher Segment */}
                  <div className="my-4">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
                      Counter Operational State
                    </span>
                    <div className="grid grid-cols-4 gap-1 p-1 bg-slate-100/80 rounded-xl text-center text-xs">
                      {(['Available', 'Serving', 'Break', 'Offline'] as CounterStatus[]).map(st => (
                        <button
                          key={st}
                          onClick={() => {
                            updateCounterStatus(counter.id, st);
                            showToast(`${counter.counter_number} status set to ${st}`, 'info');
                          }}
                          className={`py-1.5 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                            counter.status === st 
                              ? st === 'Serving' 
                                ? 'bg-blue-600 text-white shadow-xs' 
                                : st === 'Available' 
                                ? 'bg-emerald-600 text-white shadow-xs'
                                : st === 'Break'
                                ? 'bg-amber-500 text-white shadow-xs'
                                : 'bg-slate-700 text-white shadow-xs'
                              : 'text-slate-500 hover:text-slate-900'
                          }`}
                        >
                          {st}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Active Service & Queue Metrics */}
                  <div className="space-y-3 pt-2 text-xs">
                    <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between">
                      <div>
                        <span className="text-[11px] text-slate-400 block">Current Ticket</span>
                        <span className="text-base font-mono font-extrabold text-blue-600 mt-0.5 block">
                          {currentToken ? currentToken.token_number : 'None'}
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="text-[11px] text-slate-400 block">Queue Length</span>
                        <span className={`text-base font-mono font-bold mt-0.5 block ${isOverloaded ? 'text-amber-600' : 'text-slate-900'}`}>
                          {queueLength} waiting
                        </span>
                      </div>
                    </div>

                    <div>
                      <span className="text-[11px] font-semibold text-slate-400 block mb-1">
                        Assigned Services:
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {assignedServices.map(s => (
                          <span 
                            key={s.id} 
                            className="px-2 py-0.5 rounded-md text-[11px] bg-slate-100 text-slate-700 border border-slate-200"
                          >
                            {s.name} ({s.code})
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                </div>

                <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400">
                  <div className="flex items-center gap-1.5">
                    <span className={`w-2 h-2 rounded-full ${
                      counter.status === 'Available' ? 'bg-emerald-500' :
                      counter.status === 'Serving' ? 'bg-blue-500' :
                      counter.status === 'Break' ? 'bg-amber-500' : 'bg-slate-400'
                    }`} />
                    <span className="font-medium text-slate-600">{counter.status}</span>
                  </div>
                  <span className="font-mono text-[11px]">{counter.id}</span>
                </div>
              </Card>
            );
          })}
        </div>

        {/* Add / Edit Counter Modal */}
        {modalOpen && (
          <Modal
            isOpen={modalOpen}
            onClose={() => setModalOpen(false)}
            title={editingCounter ? 'Edit Service Counter' : 'Register New Counter'}
            description="Configure desk identifier, assigned staff officer, and supported departments"
          >
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Counter Identifier
                </label>
                <input
                  type="text"
                  required
                  value={counterNumber}
                  onChange={(e) => setCounterNumber(e.target.value)}
                  placeholder="e.g. Counter 06"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Assigned Staff Officer Name
                </label>
                <input
                  type="text"
                  required
                  value={staffName}
                  onChange={(e) => setStaffName(e.target.value)}
                  placeholder="e.g. Maya Lin"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Initial Status
                </label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as CounterStatus)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-600 bg-white"
                >
                  <option value="Available">Available</option>
                  <option value="Serving">Serving</option>
                  <option value="Break">Break</option>
                  <option value="Offline">Offline</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Supported Services
                </label>
                <div className="space-y-1.5 max-h-40 overflow-y-auto p-2 rounded-xl border border-slate-200">
                  {services.map(s => {
                    const isChecked = assignedServiceIds.includes(s.id);
                    return (
                      <label 
                        key={s.id} 
                        className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-slate-50 cursor-pointer text-xs"
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => toggleServiceAssignment(s.id)}
                          className="rounded text-blue-600"
                        />
                        <span className="font-medium text-slate-800">{s.name} ({s.code})</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-100">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  size="sm"
                >
                  {editingCounter ? 'Save Changes' : 'Create Counter'}
                </Button>
              </div>
            </form>
          </Modal>
        )}

      </div>
    </DashboardLayout>
  );
};
