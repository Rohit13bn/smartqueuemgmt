import React from 'react';
import { 
  Ticket, 
  Tv, 
  Clock, 
  Users, 
  ArrowRight, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  Sparkles,
  ChevronRight,
  RotateCcw,
  Volume2,
  Calendar,
  Check,
  Building2,
  Share2
} from 'lucide-react';
import { useQueue } from '../context/QueueContext';
import { DashboardLayout } from '../components/layout/DashboardLayout';
import { Button, Card, StatusBadge, EmptyState, ConfirmationDialog } from '../components/ui';

interface UserDashboardPageProps {
  onNavigate: (view: string) => void;
}

export const UserDashboardPage: React.FC<UserDashboardPageProps> = ({ onNavigate }) => {
  const { 
    currentUser, 
    tokens, 
    services, 
    counters, 
    getUserActiveToken, 
    getCurrentServingTokenForService,
    getPeopleAhead,
    getEstimatedWait,
    cancelToken,
    showToast
  } = useQueue();

  const [confirmCancelOpen, setConfirmCancelOpen] = React.useState(false);

  const activeToken = getUserActiveToken();
  const service = activeToken ? services.find(s => s.id === activeToken.service_id) : null;
  const currentlyServingToken = service ? getCurrentServingTokenForService(service.id) : null;
  
  const peopleAhead = activeToken ? getPeopleAhead(activeToken.id) : 0;
  const estimatedWait = activeToken ? getEstimatedWait(activeToken.id) : 0;
  const position = peopleAhead + 1;

  // Dynamic time greeting
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  };

  // Past user tokens
  const userPastTokens = tokens.filter(t => 
    t.user_id === currentUser.id && 
    (t.status === 'COMPLETED' || t.status === 'SKIPPED' || t.status === 'CANCELLED')
  );

  const timelineSteps = [
    { key: 'CREATED', label: 'Token Created' },
    { key: 'WAITING', label: 'In Queue' },
    { key: 'APPROACHING', label: 'Approaching' },
    { key: 'CALLED', label: 'Called' },
    { key: 'SERVING', label: 'Serving' },
    { key: 'COMPLETED', label: 'Completed' },
  ];

  const getActiveStepIndex = (status?: string, ahead: number = 0) => {
    if (!status) return 0;
    if (status === 'COMPLETED') return 5;
    if (status === 'SERVING') return 4;
    if (status === 'CALLED') return 3;
    if (ahead <= 2 && status === 'WAITING') return 2;
    if (status === 'WAITING') return 1;
    return 0;
  };

  const activeStepIdx = activeToken ? getActiveStepIndex(activeToken.status, peopleAhead) : 0;

  return (
    <DashboardLayout
      currentView="user-dashboard"
      onNavigate={onNavigate}
      title={`${getGreeting()}, ${currentUser.name}`}
      subtitle={`Student ID: ${currentUser.studentId || 'STU-2024'} · Personal Queue Command Center`}
      action={
        <Button
          variant="primary"
          size="sm"
          onClick={() => onNavigate('take-token')}
          leftIcon={<Ticket className="w-4 h-4" />}
        >
          Take New Token
        </Button>
      }
    >
      <div className="space-y-6">

        {/* ACTIVE TOKEN COMMAND CARD (The Visual Focus) */}
        {activeToken ? (
          <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden">
            
            {/* Top Bar of Active Token */}
            <div className="p-6 bg-slate-900 text-white flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 text-xs font-semibold text-blue-400">
                  <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
                  <span>ACTIVE QUEUE TICKET</span>
                  <span className="text-slate-500">·</span>
                  <span className="text-slate-300 font-medium">{service?.name}</span>
                </div>
                <h2 className="text-2xl font-bold tracking-tight text-white mt-1">
                  {service?.name}
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Issued at {new Date(activeToken.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} · Department: {service?.department}
                </p>
              </div>

              <div className="flex items-center gap-3">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => onNavigate('my-queue')}
                  className="bg-slate-800 text-white border-slate-700 hover:bg-slate-700 hover:border-slate-600"
                  leftIcon={<Clock className="w-3.5 h-3.5 text-blue-400" />}
                >
                  Live Monitor
                </Button>

                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => onNavigate('live-display')}
                  className="bg-slate-800 text-white border-slate-700 hover:bg-slate-700 hover:border-slate-600"
                  leftIcon={<Tv className="w-3.5 h-3.5 text-slate-400" />}
                >
                  TV Board
                </Button>

                <Button
                  size="sm"
                  variant="danger"
                  onClick={() => setConfirmCancelOpen(true)}
                  className="bg-rose-500/10 text-rose-300 hover:bg-rose-500/20 border-rose-500/20"
                >
                  Cancel
                </Button>
              </div>
            </div>

            {/* Core 4-Stat Metric Row */}
            <div className="p-6 grid grid-cols-2 lg:grid-cols-4 gap-4 bg-slate-50/60 border-b border-slate-100">
              
              <div className="p-4 rounded-xl bg-white border border-slate-200/80 shadow-xs">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                  Your Token
                </span>
                <span className="text-3xl sm:text-4xl font-extrabold font-mono text-blue-600 mt-1 block tracking-tight">
                  {activeToken.token_number}
                </span>
                <div className="mt-1">
                  <StatusBadge status={activeToken.status} />
                </div>
              </div>

              <div className="p-4 rounded-xl bg-white border border-slate-200/80 shadow-xs">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                  Your Position
                </span>
                <span className="text-3xl sm:text-4xl font-extrabold font-mono text-slate-900 mt-1 block tracking-tight">
                  #{position}
                </span>
                <span className="text-xs text-slate-500 mt-1 block">
                  {peopleAhead === 0 ? 'You are next in line!' : `${peopleAhead} people ahead`}
                </span>
              </div>

              <div className="p-4 rounded-xl bg-white border border-slate-200/80 shadow-xs">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                  Estimated Wait
                </span>
                <span className="text-3xl sm:text-4xl font-extrabold font-mono text-emerald-600 mt-1 block tracking-tight">
                  ~{estimatedWait}m
                </span>
                <span className="text-xs text-slate-500 mt-1 block">
                  Average desk duration
                </span>
              </div>

              <div className="p-4 rounded-xl bg-white border border-slate-200/80 shadow-xs">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                  Now Serving
                </span>
                <span className="text-3xl sm:text-4xl font-extrabold font-mono text-slate-900 mt-1 block tracking-tight">
                  {currentlyServingToken ? currentlyServingToken.token_number : 'A-024'}
                </span>
                <span className="text-xs text-slate-500 mt-1 block">
                  Counter: <strong className="text-slate-800">{activeToken.counter_number || currentlyServingToken?.counter_number || 'Counter 01'}</strong>
                </span>
              </div>

            </div>

            {/* Visual Queue Progress Indicator (Dots & Timeline) */}
            <div className="p-6 space-y-6">
              
              {/* Discrete Queue Progress Dots (e.g. ●●●○○○○) */}
              <div>
                <div className="flex items-center justify-between text-xs mb-2">
                  <span className="font-bold text-slate-700">Queue Distance</span>
                  <span className="font-mono text-slate-500 text-[11px]">
                    {peopleAhead} people ahead · Position #{position}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  {Array.from({ length: 8 }).map((_, idx) => {
                    const isServed = idx < Math.max(1, 8 - position);
                    const isCurrent = idx === Math.max(1, 8 - position);

                    return (
                      <div
                        key={idx}
                        className={`flex-1 h-3 rounded-full transition-all duration-300 ${
                          isCurrent
                            ? 'bg-blue-600 ring-2 ring-blue-300'
                            : isServed
                            ? 'bg-emerald-500'
                            : 'bg-slate-200'
                        }`}
                        title={`Slot ${idx + 1}`}
                      />
                    );
                  })}
                </div>
              </div>

              {/* Status Timeline */}
              <div>
                <span className="text-xs font-bold text-slate-700 block mb-3">
                  Service Progression Timeline
                </span>

                <div className="grid grid-cols-2 sm:grid-cols-6 gap-2">
                  {timelineSteps.map((step, idx) => {
                    const isPast = idx < activeStepIdx;
                    const isCurrent = idx === activeStepIdx;

                    return (
                      <div
                        key={step.key}
                        className={`p-3 rounded-xl border text-center transition-all ${
                          isCurrent
                            ? 'bg-blue-50 border-blue-400 text-blue-900 shadow-xs'
                            : isPast
                            ? 'bg-slate-50 border-slate-200 text-slate-600'
                            : 'bg-white border-slate-100 text-slate-400'
                        }`}
                      >
                        <div className="flex items-center justify-center mb-1.5">
                          {isPast ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                          ) : isCurrent ? (
                            <span className="w-3 h-3 rounded-full bg-blue-600 animate-pulse" />
                          ) : (
                            <span className="w-2.5 h-2.5 rounded-full bg-slate-300" />
                          )}
                        </div>
                        <span className="text-[11px] font-bold block">{step.label}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

            </div>

          </div>
        ) : (
          <Card padding="lg" className="text-center py-12">
            <div className="max-w-md mx-auto space-y-4">
              <div className="w-14 h-14 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto">
                <Ticket className="w-7 h-7" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900">No Active Queue Token</h3>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  You are not currently waiting in any department queue. Select a service counter to take your digital token and track your turn in real time.
                </p>
              </div>
              <Button
                variant="primary"
                onClick={() => onNavigate('take-token')}
                leftIcon={<Ticket className="w-4 h-4" />}
                className="mt-2"
              >
                Browse Services & Take Token
              </Button>
            </div>
          </Card>
        )}

        {/* Quick Action Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          <Card hoverable onClick={() => onNavigate('take-token')}>
            <div className="flex items-center gap-3 mb-2">
              <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
                <Ticket className="w-4 h-4" />
              </div>
              <h4 className="text-sm font-bold text-slate-900">Take Another Token</h4>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed">
              Explore examination, accounts, or scholarship desks to queue up for other requirements.
            </p>
          </Card>

          <Card hoverable onClick={() => onNavigate('my-queue')}>
            <div className="flex items-center gap-3 mb-2">
              <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                <Clock className="w-4 h-4" />
              </div>
              <h4 className="text-sm font-bold text-slate-900">Dedicated Turn Tracker</h4>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed">
              Full-screen live tracker with Web Audio call chimes and audio-visual proximity alerts.
            </p>
          </Card>

          <Card hoverable onClick={() => onNavigate('live-display')}>
            <div className="flex items-center gap-3 mb-2">
              <div className="w-9 h-9 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
                <Tv className="w-4 h-4" />
              </div>
              <h4 className="text-sm font-bold text-slate-900">Public TV Monitor Board</h4>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed">
              View the real-time public waiting hall display showing all active counters across campus.
            </p>
          </Card>
        </div>

        {/* Token History Table */}
        <Card padding="none">
          <div className="p-5 border-b border-slate-100 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Your Token History</h3>
              <p className="text-xs text-slate-500 mt-0.5">Record of resolved and past tickets under this session</p>
            </div>
            <span className="text-xs text-slate-400 font-mono">
              {userPastTokens.length} records
            </span>
          </div>

          <div className="overflow-x-auto">
            {userPastTokens.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-500">
                No past queue history recorded yet.
              </div>
            ) : (
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-400 uppercase font-mono text-[10px] border-b border-slate-100">
                  <tr>
                    <th className="px-6 py-3">Token</th>
                    <th className="px-6 py-3">Department</th>
                    <th className="px-6 py-3">Issued At</th>
                    <th className="px-6 py-3">Counter</th>
                    <th className="px-6 py-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {userPastTokens.map(tok => {
                    const srv = services.find(s => s.id === tok.service_id);
                    return (
                      <tr key={tok.id} className="hover:bg-slate-50 transition-colors">
                        <td className="px-6 py-3.5 font-mono font-bold text-slate-900">
                          {tok.token_number}
                        </td>
                        <td className="px-6 py-3.5 text-slate-700">
                          {srv?.name || 'Service'}
                        </td>
                        <td className="px-6 py-3.5 text-slate-500 font-mono">
                          {new Date(tok.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </td>
                        <td className="px-6 py-3.5 text-slate-600">
                          {tok.counter_number || 'Desk 01'}
                        </td>
                        <td className="px-6 py-3.5">
                          <StatusBadge status={tok.status} />
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
        </Card>

      </div>

      {/* Confirmation Dialog for Cancelling Active Token */}
      {activeToken && (
        <ConfirmationDialog
          isOpen={confirmCancelOpen}
          title="Cancel Active Token?"
          message={`Are you sure you want to cancel token ${activeToken.token_number}? You will forfeit your position in the queue.`}
          confirmLabel="Yes, Cancel Token"
          cancelLabel="Keep Token"
          isDestructive={true}
          onConfirm={() => {
            cancelToken(activeToken.id);
            setConfirmCancelOpen(false);
            showToast(`Token ${activeToken.token_number} was cancelled.`, 'info');
          }}
          onCancel={() => setConfirmCancelOpen(false)}
        />
      )}
    </DashboardLayout>
  );
};
