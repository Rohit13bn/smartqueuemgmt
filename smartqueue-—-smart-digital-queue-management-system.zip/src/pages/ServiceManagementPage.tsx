import React, { useState } from 'react';
import { 
  Layers, 
  Plus, 
  Edit2, 
  Trash2, 
  Clock, 
  Monitor, 
  Check, 
  X, 
  ToggleLeft, 
  ToggleRight, 
  AlertCircle,
  GraduationCap,
  Users
} from 'lucide-react';
import { useQueue } from '../context/QueueContext';
import { DashboardLayout } from '../components/layout/DashboardLayout';
import { Service } from '../types';
import { Button, Card, Modal, ConfirmationDialog } from '../components/ui';

interface ServiceManagementPageProps {
  onNavigate: (view: string) => void;
}

export const ServiceManagementPage: React.FC<ServiceManagementPageProps> = ({ onNavigate }) => {
  const { services, counters, tokens, addService, updateService, deleteService, showToast } = useQueue();

  const [modalOpen, setModalOpen] = useState(false);
  const [editingService, setEditingService] = useState<Service | null>(null);
  const [deleteConfirmService, setDeleteConfirmService] = useState<Service | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [department, setDepartment] = useState('');
  const [description, setDescription] = useState('');
  const [avgTime, setAvgTime] = useState(6);
  const [assignedCounters, setAssignedCounters] = useState<string[]>([]);
  const [formError, setFormError] = useState('');

  const handleOpenAdd = () => {
    setEditingService(null);
    setName('');
    setCode('');
    setDepartment('Academic Affairs');
    setDescription('');
    setAvgTime(6);
    setAssignedCounters(['cnt-1']);
    setFormError('');
    setModalOpen(true);
  };

  const handleOpenEdit = (srv: Service) => {
    setEditingService(srv);
    setName(srv.name);
    setCode(srv.code);
    setDepartment(srv.department);
    setDescription(srv.description);
    setAvgTime(srv.average_service_time);
    setAssignedCounters(srv.assignedCounters || []);
    setFormError('');
    setModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !code.trim()) {
      setFormError('Please enter service name and single-letter prefix.');
      return;
    }

    if (editingService) {
      updateService(editingService.id, {
        name: name.trim(),
        code: code.trim().toUpperCase(),
        department: department.trim(),
        description: description.trim(),
        average_service_time: Number(avgTime),
        assignedCounters,
      });
      showToast(`Department ${name} updated`, 'success');
    } else {
      addService({
        name: name.trim(),
        code: code.trim().toUpperCase(),
        department: department.trim(),
        description: description.trim(),
        average_service_time: Number(avgTime),
        status: 'active',
        icon: 'GraduationCap',
        assignedCounters,
      });
      showToast(`Department ${name} added`, 'success');
    }

    setModalOpen(false);
  };

  const handleToggleStatus = (srv: Service) => {
    const nextStatus = srv.status === 'active' ? 'inactive' : 'active';
    updateService(srv.id, { status: nextStatus });
    showToast(`${srv.name} set to ${nextStatus}`, 'info');
  };

  const toggleCounterAssignment = (counterId: string) => {
    setAssignedCounters(prev => 
      prev.includes(counterId) 
        ? prev.filter(c => c !== counterId) 
        : [...prev, counterId]
    );
  };

  return (
    <DashboardLayout
      currentView="service-management"
      onNavigate={onNavigate}
      title="Service Catalog Management"
      subtitle="Configure campus departments, token serial letter prefixes, standard response velocities, and assigned counters"
      isAdminMode={true}
      action={
        <Button
          variant="primary"
          size="sm"
          onClick={handleOpenAdd}
          leftIcon={<Plus className="w-3.5 h-3.5" />}
        >
          Add New Service
        </Button>
      }
    >
      <div className="space-y-6">

        {/* Services Table Card */}
        <Card padding="none" className="overflow-hidden">
          <div className="p-5 border-b border-slate-100 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Configured Campus Departments</h3>
              <p className="text-xs text-slate-500 mt-0.5">Active service centers handling student ticket dispatch</p>
            </div>
            <span className="text-xs text-slate-400 font-mono">
              {services.length} departments active
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-400 uppercase font-mono text-[10px] border-b border-slate-100">
                <tr>
                  <th className="px-6 py-3">Code</th>
                  <th className="px-6 py-3">Department Name</th>
                  <th className="px-6 py-3">Faculty / Wing</th>
                  <th className="px-6 py-3">Avg Pace</th>
                  <th className="px-6 py-3">Waiting in Queue</th>
                  <th className="px-6 py-3">Active Counters</th>
                  <th className="px-6 py-3">Status</th>
                  <th className="px-6 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium">
                {services.map(srv => {
                  const waitingCount = tokens.filter(t => t.service_id === srv.id && t.status === 'WAITING').length;
                  const activeDesks = counters.filter(c => 
                    c.status !== 'Offline' && c.assigned_service_ids.includes(srv.id)
                  ).length;

                  return (
                    <tr key={srv.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4">
                        <span className="w-8 h-8 rounded-lg bg-blue-50 text-blue-700 font-mono font-bold text-xs flex items-center justify-center border border-blue-200">
                          {srv.code}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="font-bold text-slate-900">{srv.name}</div>
                        <div className="text-[11px] text-slate-400 line-clamp-1 max-w-xs">{srv.description}</div>
                      </td>
                      <td className="px-6 py-4 text-slate-600">
                        {srv.department}
                      </td>
                      <td className="px-6 py-4 font-mono text-slate-700">
                        ~{srv.average_service_time} min
                      </td>
                      <td className="px-6 py-4 font-mono text-slate-900 font-bold">
                        {waitingCount} students
                      </td>
                      <td className="px-6 py-4 font-mono text-slate-700">
                        {activeDesks} operational
                      </td>
                      <td className="px-6 py-4">
                        <button
                          onClick={() => handleToggleStatus(srv)}
                          className="flex items-center gap-1.5 cursor-pointer text-xs"
                          title="Click to toggle status"
                        >
                          {srv.status === 'active' ? (
                            <span className="inline-flex items-center gap-1 text-emerald-600 font-semibold">
                              <span className="w-2 h-2 rounded-full bg-emerald-500" />
                              Active
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-slate-400 font-semibold">
                              <span className="w-2 h-2 rounded-full bg-slate-400" />
                              Disabled
                            </span>
                          )}
                        </button>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleOpenEdit(srv)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-blue-600 hover:bg-slate-100 transition-colors cursor-pointer"
                            title="Edit Service"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setDeleteConfirmService(srv)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                            title="Delete Service"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>

        {/* Add / Edit Service Modal */}
        {modalOpen && (
          <Modal
            isOpen={modalOpen}
            onClose={() => setModalOpen(false)}
            title={editingService ? 'Edit Campus Department' : 'Create New Service Catalog Item'}
            description="Configure department title, prefix for ticket serials, and duration pacing"
          >
            <form onSubmit={handleSubmit} className="space-y-4">
              {formError && (
                <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Department / Service Name
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Student Section"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Prefix Code
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={2}
                    value={code}
                    onChange={(e) => setCode(e.target.value.toUpperCase())}
                    placeholder="e.g. A"
                    className="w-full px-3 py-2 text-xs font-mono uppercase font-bold rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-600 text-center"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Parent Faculty / Wing
                </label>
                <input
                  type="text"
                  required
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                  placeholder="e.g. Academic Affairs"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Description
                </label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Certificates, ID issuance, verification..."
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Average Service Duration (Minutes)
                </label>
                <input
                  type="number"
                  min={1}
                  max={60}
                  value={avgTime}
                  onChange={(e) => setAvgTime(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs font-mono rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-100">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  size="sm"
                >
                  {editingService ? 'Save Changes' : 'Create Department'}
                </Button>
              </div>
            </form>
          </Modal>
        )}

        {/* Delete Confirmation Dialog with Active Usage Guard */}
        {deleteConfirmService && (
          <ConfirmationDialog
            isOpen={Boolean(deleteConfirmService)}
            title={`Delete ${deleteConfirmService.name}?`}
            message={`Are you sure you want to delete this department? Any waiting tickets in this queue may be impacted.`}
            confirmLabel="Delete Service"
            cancelLabel="Keep Department"
            isDestructive={true}
            onConfirm={() => {
              deleteService(deleteConfirmService.id);
              showToast(`${deleteConfirmService.name} deleted`, 'info');
              setDeleteConfirmService(null);
            }}
            onCancel={() => setDeleteConfirmService(null)}
          />
        )}

      </div>
    </DashboardLayout>
  );
};
