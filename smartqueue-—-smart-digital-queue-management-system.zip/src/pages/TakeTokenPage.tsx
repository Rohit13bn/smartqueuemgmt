import React, { useState } from 'react';
import { 
  GraduationCap, 
  FileText, 
  CreditCard, 
  UserCheck, 
  Award, 
  Layers,
  Clock, 
  Users, 
  Monitor, 
  ArrowRight, 
  Check, 
  Printer, 
  Share2, 
  Copy,
  AlertCircle,
  Sparkles,
  CheckCircle2,
  Tv
} from 'lucide-react';
import { useQueue } from '../context/QueueContext';
import { Service, Token } from '../types';
import { DashboardLayout } from '../components/layout/DashboardLayout';
import { Button, Card, Modal, QRCodeSVG, Badge } from '../components/ui';

interface TakeTokenPageProps {
  onNavigate: (view: string) => void;
}

export const TakeTokenPage: React.FC<TakeTokenPageProps> = ({ onNavigate }) => {
  const { 
    services, 
    counters, 
    tokens, 
    currentUser, 
    generateToken, 
    getCurrentServingTokenForService,
    getPeopleAhead,
    getEstimatedWait,
    getUserActiveToken,
    showToast
  } = useQueue();

  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [studentNameInput, setStudentNameInput] = useState(currentUser.name);
  const [issuedToken, setIssuedToken] = useState<Token | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generateError, setGenerateError] = useState('');
  const [copied, setCopied] = useState(false);

  const existingActiveToken = getUserActiveToken();

  const getServiceIcon = (iconName: string) => {
    switch (iconName) {
      case 'GraduationCap': return GraduationCap;
      case 'FileText': return FileText;
      case 'CreditCard': return CreditCard;
      case 'UserCheck': return UserCheck;
      case 'Award': return Award;
      default: return Layers;
    }
  };

  const handleSelectService = (service: Service) => {
    if (service.status !== 'active') return;
    setSelectedService(service);
    setStudentNameInput(currentUser.name);
    setGenerateError('');
    setShowConfirmModal(true);
  };

  const handleConfirmGenerate = async () => {
    if (!selectedService) return;
    setIsGenerating(true);
    setGenerateError('');

    try {
      const newToken = await generateToken(selectedService.id, studentNameInput.trim());
      setIssuedToken(newToken);
      setShowConfirmModal(false);
    } catch (err: any) {
      setGenerateError(err.message || 'Could not generate token.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopyToken = () => {
    if (!issuedToken) return;
    navigator.clipboard.writeText(issuedToken.token_number);
    setCopied(true);
    showToast(`Token ${issuedToken.token_number} copied to clipboard!`, 'success');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShareToken = async () => {
    if (!issuedToken) return;
    const shareData = {
      title: `SmartQueue Token ${issuedToken.token_number}`,
      text: `My digital token ${issuedToken.token_number} for ${selectedService?.name || 'Service'}. Status: WAITING.`,
      url: window.location.href,
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch (err) {
        // User cancelled or share failed, fallback to copy
        handleCopyToken();
      }
    } else {
      handleCopyToken();
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <DashboardLayout
      currentView="take-token"
      onNavigate={onNavigate}
      title="Take Digital Token"
      subtitle="Select the service counter you wish to visit and generate your digital queue slip"
    >
      <div className="space-y-6">

        {/* Existing Active Token Warning Banner (if user already has one) */}
        {existingActiveToken && (
          <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-amber-900">
            <div className="flex items-center gap-3">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse shrink-0" />
              <div>
                <span>You currently have an active token </span>
                <strong className="font-mono text-amber-950 font-bold">{existingActiveToken.token_number}</strong>
                <span> in {services.find(s => s.id === existingActiveToken.service_id)?.name}.</span>
              </div>
            </div>
            <Button
              size="sm"
              variant="outline"
              onClick={() => onNavigate('my-queue')}
              className="bg-white hover:bg-amber-100/50 border-amber-300 text-amber-900 shrink-0"
            >
              View Active Turn
            </Button>
          </div>
        )}

        {/* Service Directory Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service) => {
            const Icon = getServiceIcon(service.icon);
            const waitingCount = tokens.filter(t => t.service_id === service.id && t.status === 'WAITING').length;
            const currentServing = getCurrentServingTokenForService(service.id);
            const activeCounters = counters.filter(c => 
              c.status !== 'Offline' && c.assigned_service_ids.includes(service.id)
            );
            const estWait = Math.max(2, Math.ceil(((waitingCount + 1) * service.average_service_time) / Math.max(1, activeCounters.length)));
            const isAvailable = service.status === 'active';

            return (
              <Card
                key={service.id}
                hoverable={isAvailable}
                className={`flex flex-col justify-between transition-all ${
                  isAvailable 
                    ? 'hover:border-blue-400 hover:shadow-md' 
                    : 'opacity-60 bg-slate-50'
                }`}
              >
                <div>
                  {/* Top Bar of Card */}
                  <div className="flex items-start justify-between gap-3 mb-4">
                    <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                      <Icon className="w-6 h-6" />
                    </div>

                    <div className="text-right">
                      <span className="inline-block px-2 py-0.5 rounded-md text-xs font-mono font-bold bg-slate-100 text-slate-700">
                        Prefix: {service.code}
                      </span>
                      <span className="block text-[11px] font-medium text-slate-400 mt-1">
                        {isAvailable ? (
                          <span className="text-emerald-600 font-semibold">Desk Open</span>
                        ) : (
                          <span className="text-slate-500">Temporarily Offline</span>
                        )}
                      </span>
                    </div>
                  </div>

                  {/* Title & Department */}
                  <h3 className="text-base font-bold text-slate-900">{service.name}</h3>
                  <span className="text-xs font-medium text-blue-600 block mt-0.5">{service.department}</span>
                  
                  <p className="text-xs text-slate-500 mt-2.5 leading-relaxed">
                    {service.description}
                  </p>

                  {/* Detailed Queue Metrics */}
                  <div className="mt-5 pt-4 border-t border-slate-100 grid grid-cols-2 gap-3 text-xs">
                    <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                      <span className="text-[11px] text-slate-400 block">Waiting in Queue</span>
                      <span className="font-bold text-slate-900 font-mono text-sm mt-0.5 block">
                        {waitingCount} {waitingCount === 1 ? 'person' : 'people'}
                      </span>
                    </div>

                    <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                      <span className="text-[11px] text-slate-400 block">Est. Waiting Time</span>
                      <span className="font-bold text-blue-600 font-mono text-sm mt-0.5 block">
                        ~{estWait} min
                      </span>
                    </div>
                  </div>

                  <div className="mt-3 flex items-center justify-between text-xs text-slate-500 px-1">
                    <span>Now Serving: <strong className="font-mono text-slate-800">{currentServing ? currentServing.token_number : 'None'}</strong></span>
                    <span>Active Counters: <strong className="font-mono text-slate-800">{activeCounters.length}</strong></span>
                  </div>
                </div>

                {/* Take Token CTA */}
                <div className="mt-6 pt-2">
                  <Button
                    fullWidth
                    disabled={!isAvailable}
                    variant={isAvailable ? 'primary' : 'outline'}
                    onClick={() => handleSelectService(service)}
                    rightIcon={<ArrowRight className="w-4 h-4" />}
                    className="w-full"
                  >
                    {isAvailable ? 'Take Token' : 'Counter Closed'}
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>

        {/* 1. CONFIRMATION MODAL BEFORE GENERATING */}
        {selectedService && (
          <Modal
            isOpen={showConfirmModal}
            onClose={() => setShowConfirmModal(false)}
            title="Confirm Digital Token Request"
            description={`Review department details before taking a token for ${selectedService.name}`}
          >
            <div className="space-y-5">
              {generateError && (
                <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{generateError}</span>
                </div>
              )}

              {/* Summary Overview */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-2.5 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-500">Selected Service:</span>
                  <span className="font-bold text-slate-900">{selectedService.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Department:</span>
                  <span className="font-medium text-slate-700">{selectedService.department}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">People Currently Waiting:</span>
                  <span className="font-mono font-bold text-slate-900">
                    {tokens.filter(t => t.service_id === selectedService.id && t.status === 'WAITING').length}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Estimated Service Duration:</span>
                  <span className="font-mono font-bold text-slate-900">
                    ~{selectedService.average_service_time} min / ticket
                  </span>
                </div>
                <div className="flex justify-between pt-1 border-t border-slate-200">
                  <span className="text-slate-700 font-semibold">Total Estimated Wait:</span>
                  <span className="font-mono font-bold text-blue-600 text-sm">
                    ~{Math.max(2, (tokens.filter(t => t.service_id === selectedService.id && t.status === 'WAITING').length + 1) * selectedService.average_service_time)} min
                  </span>
                </div>
              </div>

              {/* User Name Input for Desk Announcement */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Name for Announcement
                </label>
                <input
                  type="text"
                  required
                  value={studentNameInput}
                  onChange={(e) => setStudentNameInput(e.target.value)}
                  placeholder="Enter your name"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
                <span className="text-[11px] text-slate-400 mt-1 block">
                  This name will display to the staff officer when your turn is dispatched.
                </span>
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowConfirmModal(false)}
                >
                  Cancel
                </Button>
                <Button
                  variant="primary"
                  size="sm"
                  isLoading={isGenerating}
                  onClick={handleConfirmGenerate}
                  leftIcon={<Check className="w-4 h-4" />}
                >
                  Confirm & Take Token
                </Button>
              </div>
            </div>
          </Modal>
        )}

        {/* 2. SUCCESS VOUCHER MODAL (With QR Code, Copy, Share, Print) */}
        {issuedToken && (
          <Modal
            isOpen={Boolean(issuedToken)}
            onClose={() => setIssuedToken(null)}
            maxWidth="md"
          >
            <div className="space-y-6">
              
              {/* Success Header Banner */}
              <div className="text-center">
                <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto mb-3">
                  <CheckCircle2 className="w-6 h-6 stroke-[2.5]" />
                </div>
                <h3 className="text-xl font-extrabold text-slate-900 tracking-tight">
                  Token Generated Successfully
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Your place in the digital queue is confirmed
                </p>
              </div>

              {/* Printable Ticket Card */}
              <div className="p-6 rounded-2xl bg-slate-50 border-2 border-dashed border-slate-200 text-center space-y-4" id="printable-ticket">
                <div>
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-widest block">
                    Your Token Number
                  </span>
                  <div className="text-5xl font-extrabold font-mono text-blue-600 tracking-tight mt-1">
                    {issuedToken.token_number}
                  </div>
                  <div className="text-sm font-bold text-slate-800 mt-1">
                    {services.find(s => s.id === issuedToken.service_id)?.name}
                  </div>
                  <div className="text-xs text-slate-500">
                    Holder: <strong className="text-slate-700">{issuedToken.user_name}</strong>
                  </div>
                </div>

                {/* SVG QR Code */}
                <div className="flex justify-center py-2">
                  <QRCodeSVG 
                    value={`https://smartqueue.ac.in/verify?token=${issuedToken.token_number}&id=${issuedToken.id}`} 
                    size={120} 
                  />
                </div>

                {/* Key Status Metrics */}
                <div className="grid grid-cols-2 gap-3 text-xs pt-2 border-t border-slate-200">
                  <div className="p-2.5 rounded-xl bg-white border border-slate-200/80">
                    <span className="text-[11px] text-slate-400 block">Queue Position</span>
                    <span className="font-bold text-slate-900 font-mono text-sm mt-0.5 block">
                      #{getPeopleAhead(issuedToken.id) + 1} ({getPeopleAhead(issuedToken.id)} ahead)
                    </span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-white border border-slate-200/80">
                    <span className="text-[11px] text-slate-400 block">Estimated Wait</span>
                    <span className="font-bold text-blue-600 font-mono text-sm mt-0.5 block">
                      ~{getEstimatedWait(issuedToken.id)} min
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs text-slate-500 px-1 pt-1">
                  <span>Now Serving: <strong className="font-mono text-slate-800">{getCurrentServingTokenForService(issuedToken.service_id)?.token_number || 'A-024'}</strong></span>
                  <span>Counter: <strong className="text-slate-800">{issuedToken.counter_number || 'On Call'}</strong></span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2.5">
                <Button
                  fullWidth
                  variant="primary"
                  onClick={() => {
                    setIssuedToken(null);
                    onNavigate('my-queue');
                  }}
                  rightIcon={<ArrowRight className="w-4 h-4" />}
                  className="w-full py-3"
                >
                  Track My Queue Turn
                </Button>

                <div className="grid grid-cols-3 gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleCopyToken}
                    leftIcon={copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  >
                    {copied ? 'Copied' : 'Copy'}
                  </Button>

                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleShareToken}
                    leftIcon={<Share2 className="w-3.5 h-3.5" />}
                  >
                    Share
                  </Button>

                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handlePrint}
                    leftIcon={<Printer className="w-3.5 h-3.5" />}
                  >
                    Print
                  </Button>
                </div>
              </div>

            </div>
          </Modal>
        )}

      </div>
    </DashboardLayout>
  );
};
