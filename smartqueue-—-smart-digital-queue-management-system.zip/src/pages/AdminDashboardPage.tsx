import React, { useState } from 'react';
import { 
  Users, 
  Clock, 
  CheckCircle2, 
  Hourglass, 
  PhoneCall, 
  SkipForward, 
  RotateCcw, 
  ArrowRightLeft, 
  PauseCircle, 
  Play, 
  Search, 
  Filter, 
  ShieldAlert, 
  Sparkles,
  Ticket,
  Check,
  ChevronDown,
  Monitor,
  Activity,
  AlertTriangle,
  RefreshCw
} from 'lucide-react';
import { useQueue } from '../context/QueueContext';
import { DashboardLayout } from '../components/layout/DashboardLayout';
import { Token, QueueStatus } from '../types';
import { Button, Card, StatCard, StatusBadge, Modal, ConfirmationDialog } from '../components/ui';

interface AdminDashboardPageProps {
  onNavigate: (view: string) => void;
  onOpenAuth: () => void;
}

export const AdminDashboardPage: React.FC<AdminDashboardPageProps> = ({ onNavigate, onOpenAuth }) => {
  const { 
    currentUser, 
    tokens, 
    counters, 
    services, 
    getMetrics, 
    callNextToken, 
    recallToken, 
    serveToken, 
    completeToken, 
    skipToken, 
    cancelToken,
    holdToken, 
    transferToken, 
    loginAs,
    showToast
  } = useQueue();

  const metrics = getMetrics();

  // Filters & State
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [serviceFilter, setServiceFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCounterId, setSelectedCounterId] = useState<string>(counters[0]?.id || '');

  // Modal states
  const [transferringToken, setTransferringToken] = useState<Token | null>(null);
  const [targetTransferServiceId, setTargetTransferServiceId] = useState<string>(services[0]?.id || '');
  const [cancelConfirmToken, setCancelConfirmToken] = useState<Token | null>(null);

  // Role validation check
  if (currentUser.role !== 'admin') {
    return (
      <DashboardLayout
        currentView="admin-dashboard"
        onNavigate={onNavigate}
        title="Admin Operations Restricted"
        subtitle="Staff or Administrator role validation required"
        isAdminMode={true}
      >
        <Card padding="lg" className="max-w-md mx-auto my-12 text-center">
          <div className="w-14 h-14 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mx-auto mb-4">
            <ShieldAlert className="w-7 h-7" />
          </div>
          <h3 className="text-base font-bold text-slate-900">Administrator Access Required</h3>
          <p className="text-xs text-slate-500 mt-1 leading-relaxed">
            You are currently signed in as a User ({currentUser.name}). Switch to administrative credentials to dispatch tokens and manage queue counters.
          </p>
          <div className="pt-5 flex flex-col gap-2.5">
            <Button
              variant="primary"
              fullWidth
              onClick={() => loginAs('admin')}
              className="w-full py-2.5"
            >
              Sign In as Administrator (Prof. Sharma)
            </Button>
            <Button
              variant="outline"
              fullWidth
              onClick={onOpenAuth}
              className="w-full py-2.5"
            >
              Switch Account Credentials
            </Button>
          </div>
        </Card>
      </DashboardLayout>
    );
  }

  // Filtered tokens
  const filteredTokens = tokens.filter(token => {
    if (statusFilter !== 'ALL' && token.status !== statusFilter) return false;
    if (serviceFilter !== 'ALL' && token.service_id !== serviceFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchNumber = token.token_number.toLowerCase().includes(q);
      const matchName = token.user_name.toLowerCase().includes(q);
      if (!matchNumber && !matchName) return false;
    }
    return true;
  });

  const activeWaitingTokens = tokens.filter(t => t.status === 'WAITING');
  const activeServingTokens = tokens.filter(t => t.status === 'SERVING' || t.status === 'CALLED');
  const activeCounters = counters.filter(c => c.status !== 'Offline');
  
  const completedTokensCount = tokens.filter(t => t.status === 'COMPLETED').length;
  const skippedOrCancelledCount = tokens.filter(t => t.status === 'SKIPPED' || t.status === 'CANCELLED').length;
  const queueEfficiency = Math.round(
    (completedTokensCount / Math.max(1, completedTokensCount + skippedOrCancelledCount)) * 100
  );

  const handleCallNext = async () => {
    try {
      const called = await callNextToken(selectedCounterId || undefined);
      if (called) {
        showToast(`Token ${called.token_number} called to ${called.counter_number || 'Counter'}`, 'success');
      } else {
        showToast('No waiting tokens available in queue', 'info');
      }
    } catch (err: any) {
      showToast(err.message || 'Could not call next token', 'error');
    }
  };

  const handleConfirmTransfer = () => {
    if (transferringToken && targetTransferServiceId) {
      transferToken(transferringToken.id, targetTransferServiceId);
      const targetSrv = services.find(s => s.id === targetTransferServiceId);
      showToast(`Token ${transferringToken.token_number} transferred to ${targetSrv?.name}`, 'success');
      setTransferringToken(null);
    }
  };

  return (
    <DashboardLayout
      currentView="admin-dashboard"
      onNavigate={onNavigate}
      title="Queue Operations Center"
      subtitle="Operational dispatcher for campus service desks, token queue sequences, and staff routing"
      isAdminMode={true}
      action={
        <div className="flex items-center gap-2">
          {/* Desk selector for Call Next */}
          <select
            value={selectedCounterId}
            onChange={(e) => setSelectedCounterId(e.target.value)}
            className="px-3 py-2 bg-white text-xs font-semibold rounded-xl border border-slate-300 text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-600"
          >
            {counters.map(c => (
              <option key={c.id} value={c.id}>
                {c.counter_number} ({c.staff_name})
              </option>
            ))}
          </select>

          <Button
            variant="primary"
            size="sm"
            onClick={handleCallNext}
            leftIcon={<PhoneCall className="w-3.5 h-3.5" />}
          >
            Call Next Token
          </Button>
        </div>
      }
    >
      <div className="space-y-6">

        {/* 1. TOP 6 KPI METRIC CARDS */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          <StatCard
            title="Waiting"
            value={metrics.waitingCount}
            subtitle="In active queue"
            variant="brand"
            icon={<Hourglass className="w-4 h-4" />}
          />

          <StatCard
            title="Serving"
            value={metrics.servingCount}
            subtitle="At service desks"
            variant="success"
            icon={<PhoneCall className="w-4 h-4" />}
          />

          <StatCard
            title="Served Today"
            value={metrics.servedTodayCount}
            subtitle="Resolved tickets"
            variant="default"
            icon={<CheckCircle2 className="w-4 h-4" />}
          />

          <StatCard
            title="Average Wait"
            value={`${metrics.avgWaitMinutes}m`}
            subtitle="Queue response"
            variant="warning"
            icon={<Clock className="w-4 h-4" />}
          />

          <StatCard
            title="Active Counters"
            value={activeCounters.length}
            subtitle={`of ${counters.length} total desks`}
            variant="brand"
            icon={<Monitor className="w-4 h-4" />}
          />

          <StatCard
            title="Efficiency"
            value={`${queueEfficiency}%`}
            subtitle="Completion rate"
            variant="success"
            icon={<Activity className="w-4 h-4" />}
          />
        </div>

        {/* 2. REAL-TIME QUEUE OVERVIEW WITH SEARCH & FILTERS */}
        <Card padding="none" className="overflow-hidden">
          
          {/* Controls Bar */}
          <div className="p-5 border-b border-slate-100 flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-white">
            <div>
              <h3 className="text-base font-bold text-slate-900">Active Queue Dispatch</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Real-time monitor of student tickets and desk assignments
              </p>
            </div>

            {/* Search & Filter Controls */}
            <div className="flex flex-wrap items-center gap-2.5">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search token or student..."
                  className="pl-8 pr-3 py-1.5 text-xs rounded-xl border border-slate-300 w-44 sm:w-56 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>

              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-3 py-1.5 text-xs rounded-xl border border-slate-300 text-slate-700 bg-white focus:outline-none focus:ring-2 focus:ring-blue-600"
              >
                <option value="ALL">All Statuses</option>
                <option value="WAITING">Waiting</option>
                <option value="CALLED">Called</option>
                <option value="SERVING">Serving</option>
                <option value="HOLD">On Hold</option>
                <option value="COMPLETED">Completed</option>
                <option value="SKIPPED">Skipped</option>
                <option value="CANCELLED">Cancelled</option>
              </select>

              <select
                value={serviceFilter}
                onChange={(e) => setServiceFilter(e.target.value)}
                className="px-3 py-1.5 text-xs rounded-xl border border-slate-300 text-slate-700 bg-white focus:outline-none focus:ring-2 focus:ring-blue-600"
              >
                <option value="ALL">All Departments</option>
                {services.map(s => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Data Table */}
          <div className="overflow-x-auto">
            {filteredTokens.length === 0 ? (
              <div className="p-12 text-center text-xs text-slate-500">
                No tickets match the selected filter criteria.
              </div>
            ) : (
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-400 uppercase font-mono text-[10px] border-b border-slate-100">
                  <tr>
                    <th className="px-6 py-3">Token</th>
                    <th className="px-6 py-3">Department</th>
                    <th className="px-6 py-3">Holder</th>
                    <th className="px-6 py-3">Status</th>
                    <th className="px-6 py-3">Est. Wait</th>
                    <th className="px-6 py-3">Assigned Counter</th>
                    <th className="px-6 py-3 text-right">Quick Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {filteredTokens.map(tok => {
                    const srv = services.find(s => s.id === tok.service_id);
                    const isWaiting = tok.status === 'WAITING';
                    const isCalled = tok.status === 'CALLED';
                    const isServing = tok.status === 'SERVING';
                    const isHold = tok.status === 'HOLD';

                    return (
                      <tr key={tok.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="px-6 py-3.5 font-mono font-extrabold text-blue-600 text-sm">
                          {tok.token_number}
                        </td>
                        <td className="px-6 py-3.5 text-slate-800">
                          {srv?.name || 'Department'}
                        </td>
                        <td className="px-6 py-3.5 text-slate-600">
                          {tok.user_name}
                        </td>
                        <td className="px-6 py-3.5">
                          <StatusBadge status={tok.status} />
                        </td>
                        <td className="px-6 py-3.5 font-mono text-slate-600">
                          ~{tok.estimated_wait_min} min
                        </td>
                        <td className="px-6 py-3.5 text-slate-700">
                          {tok.counter_number || <span className="text-slate-400 italic">Unassigned</span>}
                        </td>
                        
                        {/* Operational Quick Actions */}
                        <td className="px-6 py-3.5 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            
                            {/* Recall / Call */}
                            {isWaiting && (
                              <button
                                onClick={() => callNextToken(undefined, tok.service_id)}
                                className="px-2.5 py-1 rounded-lg bg-blue-50 text-blue-700 hover:bg-blue-100 font-semibold text-[11px] transition-colors cursor-pointer"
                                title="Call this token to counter"
                              >
                                Call
                              </button>
                            )}

                            {isCalled && (
                              <>
                                <button
                                  onClick={() => recallToken(tok.id)}
                                  className="px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-100 font-semibold text-[11px] transition-colors cursor-pointer"
                                  title="Repeat announcement chime"
                                >
                                  Recall
                                </button>
                                <button
                                  onClick={() => serveToken(tok.id)}
                                  className="px-2.5 py-1 rounded-lg bg-blue-600 text-white hover:bg-blue-700 font-semibold text-[11px] transition-colors cursor-pointer"
                                  title="Mark as being served at desk"
                                >
                                  Serve
                                </button>
                              </>
                            )}

                            {isServing && (
                              <button
                                onClick={() => completeToken(tok.id)}
                                className="px-2.5 py-1 rounded-lg bg-emerald-600 text-white hover:bg-emerald-700 font-semibold text-[11px] transition-colors cursor-pointer"
                                title="Mark service ticket as completed"
                              >
                                Complete
                              </button>
                            )}

                            {/* Transfer Action */}
                            {(isWaiting || isServing || isCalled) && (
                              <button
                                onClick={() => {
                                  setTransferringToken(tok);
                                  setTargetTransferServiceId(services.find(s => s.id !== tok.service_id)?.id || services[0]?.id || '');
                                }}
                                className="px-2 py-1 rounded-lg text-slate-600 hover:bg-slate-100 font-semibold text-[11px] transition-colors cursor-pointer"
                                title="Transfer to another department"
                              >
                                Transfer
                              </button>
                            )}

                            {/* Hold / Resume */}
                            {isWaiting && (
                              <button
                                onClick={() => holdToken(tok.id)}
                                className="px-2 py-1 rounded-lg text-slate-600 hover:bg-slate-100 font-semibold text-[11px] transition-colors cursor-pointer"
                                title="Place token on hold"
                              >
                                Hold
                              </button>
                            )}

                            {/* Skip */}
                            {(isWaiting || isCalled) && (
                              <button
                                onClick={() => skipToken(tok.id)}
                                className="px-2 py-1 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100 font-semibold text-[11px] transition-colors cursor-pointer"
                                title="Skip token"
                              >
                                Skip
                              </button>
                            )}

                            {/* Cancel */}
                            {(isWaiting || isCalled || isHold) && (
                              <button
                                onClick={() => setCancelConfirmToken(tok)}
                                className="px-2 py-1 rounded-lg text-rose-600 hover:bg-rose-50 font-semibold text-[11px] transition-colors cursor-pointer"
                                title="Cancel token"
                              >
                                Cancel
                              </button>
                            )}

                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
        </Card>

      </div>

      {/* 3. TRANSFER DEPARTMENT MODAL */}
      {transferringToken && (
        <Modal
          isOpen={Boolean(transferringToken)}
          onClose={() => setTransferringToken(null)}
          title={`Transfer Token ${transferringToken.token_number}`}
          description={`Re-assign ${transferringToken.user_name} to a different department without losing queue seniority`}
        >
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Select Target Department
              </label>
              <select
                value={targetTransferServiceId}
                onChange={(e) => setTargetTransferServiceId(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-600"
              >
                {services.map(s => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.department}) - Prefix {s.code}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-100">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setTransferringToken(null)}
              >
                Cancel
              </Button>
              <Button
                variant="primary"
                size="sm"
                onClick={handleConfirmTransfer}
                leftIcon={<ArrowRightLeft className="w-3.5 h-3.5" />}
              >
                Confirm Transfer
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* 4. CANCEL CONFIRMATION DIALOG */}
      {cancelConfirmToken && (
        <ConfirmationDialog
          isOpen={Boolean(cancelConfirmToken)}
          title="Cancel Student Ticket?"
          message={`Are you sure you want to cancel token ${cancelConfirmToken.token_number} for ${cancelConfirmToken.user_name}?`}
          confirmLabel="Cancel Token"
          cancelLabel="Keep Ticket"
          isDestructive={true}
          onConfirm={() => {
            cancelToken(cancelConfirmToken.id);
            showToast(`Token ${cancelConfirmToken.token_number} was cancelled`, 'info');
            setCancelConfirmToken(null);
          }}
          onCancel={() => setCancelConfirmToken(null)}
        />
      )}

    </DashboardLayout>
  );
};
