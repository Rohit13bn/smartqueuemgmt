export type Role = 'user' | 'admin' | 'staff';

export type QueueStatus = 
  | 'WAITING' 
  | 'CALLED' 
  | 'SERVING' 
  | 'COMPLETED' 
  | 'SKIPPED' 
  | 'CANCELLED' 
  | 'HOLD';

export type CounterStatus = 'Available' | 'Serving' | 'Break' | 'Offline';

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  studentId?: string;
  phone?: string;
}

export interface Service {
  id: string;
  code: string; // e.g., 'A', 'E', 'F', 'D', 'S'
  name: string;
  description: string;
  department: string;
  average_service_time: number; // in minutes
  status: 'active' | 'inactive';
  icon: string;
  assignedCounters: string[]; // Counter IDs
}

export interface Counter {
  id: string;
  counter_number: string; // e.g. "Counter 01"
  assigned_service_ids: string[]; // Service IDs this counter handles
  staff_name: string;
  status: CounterStatus;
  current_token_id?: string;
}

export interface Token {
  id: string;
  token_number: string; // e.g. "A-024"
  service_id: string;
  user_id: string;
  user_name: string;
  counter_id?: string;
  counter_number?: string;
  status: QueueStatus;
  created_at: string;
  called_at?: string;
  completed_at?: string;
  estimated_wait_min: number;
  priority?: boolean;
  notes?: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  type: 'info' | 'approaching' | 'called' | 'success';
  read: boolean;
  token_number?: string;
}

export interface QueueMetric {
  waitingCount: number;
  servingCount: number;
  servedTodayCount: number;
  avgWaitMinutes: number;
}
