import React, { createContext, useContext, useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { 
  Service, 
  Counter, 
  Token, 
  User, 
  NotificationItem, 
  QueueMetric, 
  CounterStatus 
} from '../types';
import { 
  INITIAL_SERVICES, 
  INITIAL_COUNTERS, 
  INITIAL_TOKENS, 
  INITIAL_USERS 
} from '../data/initialData';
import { chimeSynthesizer } from '../utils/audioChime';
import { ToastMessage } from '../components/common/ToastContainer';

interface QueueContextType {
  services: Service[];
  counters: Counter[];
  tokens: Token[];
  currentUser: User;
  users: User[];
  notifications: NotificationItem[];
  toasts: ToastMessage[];
  soundEnabled: boolean;
  lastCalledToken: Token | null;
  isLoading: boolean;
  showToast: (message: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
  dismissToast: (id: string) => void;
  
  // Token lifecycle
  generateToken: (serviceId: string, customName?: string) => Promise<Token>;
  callNextToken: (counterId?: string, serviceId?: string) => Promise<Token | null>;
  recallToken: (tokenId: string) => Promise<void>;
  serveToken: (tokenId: string) => Promise<void>;
  completeToken: (tokenId: string) => Promise<void>;
  skipToken: (tokenId: string) => Promise<void>;
  holdToken: (tokenId: string) => Promise<void>;
  transferToken: (tokenId: string, targetServiceId: string) => Promise<void>;
  cancelToken: (tokenId: string) => Promise<void>;
  resetQueue: () => Promise<void>;

  // Management
  addService: (service: Omit<Service, 'id'>) => Promise<void>;
  updateService: (id: string, updates: Partial<Service>) => Promise<void>;
  deleteService: (id: string) => Promise<void>;
  
  addCounter: (counter: Omit<Counter, 'id'>) => Promise<void>;
  updateCounter: (id: string, updates: Partial<Counter>) => Promise<void>;
  updateCounterStatus: (id: string, status: CounterStatus) => Promise<void>;

  // Auth & Settings
  setCurrentUser: (user: User) => void;
  loginAs: (role: 'user' | 'admin' | 'staff') => Promise<void>;
  loginWithEmail: (email: string, password?: string) => Promise<{ success: boolean; error?: string }>;
  registerUser: (name: string, email: string, studentId?: string, password?: string) => Promise<{ success: boolean; error?: string; user?: User }>;
  forgotPassword: (email: string) => Promise<{ success: boolean; message?: string; error?: string }>;
  logout: () => void;
  toggleSound: () => boolean;
  playCalledNotificationSound: (tokenId?: string) => boolean;
  dismissNotification: (id: string) => void;
  clearNotifications: () => void;

  // Derived helpers
  getPeopleAhead: (tokenId: string) => number;
  getEstimatedWait: (tokenId: string) => number;
  getCurrentServingTokenForService: (serviceId: string) => Token | null;
  getUserActiveToken: () => Token | null;
  getMetrics: () => QueueMetric;
}

const QueueContext = createContext<QueueContextType | undefined>(undefined);

const STORAGE_KEY_USER = 'sq_current_user_v1';
const STORAGE_KEY_TOKEN = 'sq_auth_token_v1';
const STORAGE_KEY_SOUND = 'sq_sound_enabled_v1';

/**
 * Web Audio API Notification Utility
 * Plays a short, subtle 'ding' sound when a token status changes to 'CALLED'.
 * Handles browser autoplay policies by waiting for user interaction and
 * guarantees that audio is triggered only once per status update.
 */
export class WebAudioQueueNotifier {
  private ctx: AudioContext | null = null;
  private hasInteracted: boolean = false;
  private pendingDing: boolean = false;
  private alertedTokenStatusKeys: Set<string> = new Set();

  constructor() {
    if (typeof window !== 'undefined') {
      const handleUserInteraction = () => {
        this.hasInteracted = true;
        this.unlockContext();
        if (this.pendingDing) {
          this.pendingDing = false;
          this.playSubtleDing();
        }
        window.removeEventListener('click', handleUserInteraction);
        window.removeEventListener('touchstart', handleUserInteraction);
        window.removeEventListener('keydown', handleUserInteraction);
      };

      window.addEventListener('click', handleUserInteraction, { once: true, passive: true });
      window.addEventListener('touchstart', handleUserInteraction, { once: true, passive: true });
      window.addEventListener('keydown', handleUserInteraction, { once: true, passive: true });
    }
  }

  private getAudioContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    return this.ctx;
  }

  private unlockContext(): void {
    const ctx = this.getAudioContext();
    if (ctx && ctx.state === 'suspended') {
      ctx.resume().catch(() => {});
    }
  }

  /**
   * Synthesize a short, subtle, pleasant 'ding' bell chime using Web Audio API
   */
  public playSubtleDing(): void {
    const ctx = this.getAudioContext();
    if (!ctx) return;

    // Handle browser autoplay policy: if context is suspended or no user interaction yet,
    // queue the sound to play as soon as the user interacts with the page.
    if (ctx.state === 'suspended' || !this.hasInteracted) {
      this.pendingDing = true;
      this.unlockContext();
      return;
    }

    try {
      const now = ctx.currentTime;

      // Primary delicate bell fundamental (B5 ~ 987.77 Hz)
      const osc1 = ctx.createOscillator();
      const gain1 = ctx.createGain();
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(987.77, now);

      gain1.gain.setValueAtTime(0, now);
      gain1.gain.linearRampToValueAtTime(0.28, now + 0.01); // 10ms gentle attack
      gain1.gain.exponentialRampToValueAtTime(0.0008, now + 0.65); // Subtle 650ms decay

      osc1.connect(gain1);
      gain1.connect(ctx.destination);

      osc1.start(now);
      osc1.stop(now + 0.7);

      // Shimmering crystalline overtone (B6 ~ 1975.53 Hz)
      const osc2 = ctx.createOscillator();
      const gain2 = ctx.createGain();
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(1975.53, now);

      gain2.gain.setValueAtTime(0, now);
      gain2.gain.linearRampToValueAtTime(0.12, now + 0.008);
      gain2.gain.exponentialRampToValueAtTime(0.0004, now + 0.45);

      osc2.connect(gain2);
      gain2.connect(ctx.destination);

      osc2.start(now);
      osc2.stop(now + 0.5);
    } catch (e) {
      console.warn('Web Audio playback error:', e);
    }
  }

  /**
   * Plays the notification sound only once per status update to 'CALLED'
   * for the given token ID.
   */
  public notifyCalledOnce(tokenId: string): boolean {
    const statusKey = `${tokenId}:CALLED`;
    if (this.alertedTokenStatusKeys.has(statusKey)) {
      // Already played for this token's current CALLED state
      return false;
    }

    this.alertedTokenStatusKeys.add(statusKey);
    this.playSubtleDing();
    return true;
  }

  /**
   * Resets the single-trigger alert key for a token when its status changes
   */
  public resetAlertKey(tokenId: string): void {
    this.alertedTokenStatusKeys.delete(`${tokenId}:CALLED`);
  }
}

export const webAudioQueueNotifier = new WebAudioQueueNotifier();

/**
 * Custom Hook: useTokenStatusAudioNotification
 * Watches the user's active token and triggers the Web Audio notification ding
 * whenever its status changes to 'CALLED'.
 * Guarantees that the audio is triggered exactly once per status update and
 * respects browser autoplay policies by queuing and unlocking on user gesture.
 */
export function useTokenStatusAudioNotification(
  activeToken: Token | null,
  soundEnabled: boolean = true
) {
  const previousStatusRef = useRef<string | null>(null);

  useEffect(() => {
    if (!activeToken) {
      previousStatusRef.current = null;
      return;
    }

    const currentStatus = activeToken.status;
    const previousStatus = previousStatusRef.current;

    // Trigger ONLY when transitioning to 'CALLED' from a different state (or initial detection)
    if (currentStatus === 'CALLED' && previousStatus !== 'CALLED') {
      if (soundEnabled) {
        webAudioQueueNotifier.notifyCalledOnce(activeToken.id);
      }
    } else if (currentStatus !== 'CALLED' && previousStatus === 'CALLED') {
      // Clean up alert key when token moves away from CALLED
      webAudioQueueNotifier.resetAlertKey(activeToken.id);
    }

    previousStatusRef.current = currentStatus;
  }, [activeToken?.id, activeToken?.status, soundEnabled]);
}

export const QueueProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [services, setServices] = useState<Service[]>(INITIAL_SERVICES);
  const [counters, setCounters] = useState<Counter[]>(INITIAL_COUNTERS);
  const [tokens, setTokens] = useState<Token[]>(INITIAL_TOKENS);
  const [users, setUsers] = useState<User[]>(INITIAL_USERS);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const [currentUser, setCurrentUser] = useState<User>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_USER);
      if (saved) return JSON.parse(saved);
    } catch { /* fallback */ }
    return INITIAL_USERS[0]; // Alex Morgan (Student)
  });

  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_SOUND);
      return saved !== null ? JSON.parse(saved) : true;
    } catch {
      return true;
    }
  });

  const [lastCalledToken, setLastCalledToken] = useState<Token | null>(null);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([
    {
      id: 'notif-welcome',
      title: 'Active Token Assigned',
      message: 'Token A-027 is active in queue. 2 people ahead of you.',
      timestamp: '10 min ago',
      type: 'info',
      read: false,
      token_number: 'A-027',
    }
  ]);

  const showToast = useCallback((message: string, type: 'success' | 'info' | 'warning' | 'error' = 'info') => {
    const id = 'toast-' + Date.now() + '-' + Math.random().toString(36).substring(2, 5);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // Compute active token for current user
  const activeToken = useMemo(() => {
    return tokens.find((t) => 
      t.user_id === currentUser.id && 
      (t.status === 'WAITING' || t.status === 'CALLED' || t.status === 'SERVING')
    ) || null;
  }, [tokens, currentUser.id]);

  // Hook to monitor active token status and play subtle ding when 'CALLED'
  useTokenStatusAudioNotification(activeToken, soundEnabled);

  // Track previous token statuses to detect transitions to 'CALLED'
  const prevTokenStatusRef = useRef<Record<string, string>>({});
  const initialLoadDone = useRef(false);

  // Helper for authenticated fetch headers
  const getAuthHeaders = useCallback(() => {
    const token = localStorage.getItem(STORAGE_KEY_TOKEN) || currentUser.id;
    return {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
      'x-user-uid': currentUser.id,
    };
  }, [currentUser]);

  // Map backend token to frontend Token interface
  const mapBackendToken = (t: any): Token => ({
    id: t.id,
    token_number: t.tokenNumber || t.token_number,
    service_id: t.serviceId || t.service_id,
    user_id: t.userId || t.user_id,
    user_name: t.userName || t.user_name || 'Student',
    counter_id: t.counterId || t.counter_id || undefined,
    counter_number: t.counterNumber || t.counter_number || undefined,
    status: t.status,
    created_at: t.createdAt || t.created_at,
    called_at: t.calledAt || t.called_at || undefined,
    completed_at: t.completedAt || t.completed_at || undefined,
    estimated_wait_min: t.estimatedWaitTime ?? t.estimated_wait_min ?? 5,
  });

  // Map backend service to frontend Service interface
  const mapBackendService = (s: any): Service => ({
    id: s.id,
    code: s.prefix || s.code,
    name: s.name,
    description: s.description || '',
    department: s.department || 'Academic Affairs',
    average_service_time: s.averageServiceTime ?? s.average_service_time ?? 6,
    status: s.status === 'ACTIVE' || s.status === 'active' ? 'active' : 'inactive',
    icon: s.icon || 'GraduationCap',
    assignedCounters: s.assignedCounters || ['cnt-1', 'cnt-2', 'cnt-3', 'cnt-4', 'cnt-5'],
  });

  // Map backend counter to frontend Counter interface
  const mapBackendCounter = (c: any): Counter => ({
    id: c.id,
    counter_number: c.counterNumber || c.counter_number,
    assigned_service_ids: Array.isArray(c.serviceId) ? c.serviceId : [c.serviceId || 'srv-student'],
    staff_name: c.assignedStaff || c.staff_name || 'Staff Officer',
    status: (c.status?.charAt(0).toUpperCase() + c.status?.slice(1).toLowerCase()) as CounterStatus || 'Available',
    current_token_id: c.currentTokenId || c.current_token_id || undefined,
  });

  // Fetch all data from backend
  const refreshData = useCallback(async () => {
    try {
      const [resSrv, resCnt, resTok, resNotif] = await Promise.all([
        fetch('/api/services'),
        fetch('/api/counters'),
        fetch('/api/tokens'),
        fetch(`/api/notifications?userId=${encodeURIComponent(currentUser.id)}`),
      ]);

      if (resSrv.ok) {
        const srvData = await resSrv.json();
        setServices(srvData.map(mapBackendService));
      }

      if (resCnt.ok) {
        const cntData = await resCnt.json();
        setCounters(cntData.map(mapBackendCounter));
      }

      if (resTok.ok) {
        const tokData = await resTok.json();
        const mappedTokens = tokData.map(mapBackendToken);
        setTokens(mappedTokens);

        // Detect if any user token transitioned to 'CALLED'
        if (initialLoadDone.current) {
          mappedTokens.forEach((tok: Token) => {
            const prevStatus = prevTokenStatusRef.current[tok.id];
            if (tok.user_id === currentUser.id && tok.status === 'CALLED' && prevStatus !== 'CALLED') {
              // Play the subtle 'ding' sound to alert the user even when looking away from the screen!
              if (soundEnabled) {
                chimeSynthesizer.playCalledDing();
              }
              chimeSynthesizer.startTabAlert(tok.token_number, tok.counter_number);

              setNotifications(prev => [
                {
                  id: 'notif-' + Date.now(),
                  title: 'Turn Called!',
                  message: `Your token ${tok.token_number} is being called! Please proceed to ${tok.counter_number || 'the counter'}.`,
                  timestamp: 'Just now',
                  type: 'called',
                  read: false,
                  token_number: tok.token_number,
                },
                ...prev,
              ]);
            } else if (tok.user_id === currentUser.id && prevStatus === 'CALLED' && tok.status !== 'CALLED') {
              chimeSynthesizer.stopTabAlert();
            }
          });
        }

        // Update ref
        const newStatusMap: Record<string, string> = {};
        mappedTokens.forEach((t: Token) => {
          newStatusMap[t.id] = t.status;
        });
        prevTokenStatusRef.current = newStatusMap;
        initialLoadDone.current = true;
      }

      if (resNotif.ok) {
        const notifData = await resNotif.json();
        if (Array.isArray(notifData) && notifData.length > 0) {
          const mapped = notifData.map((n: any) => ({
            id: n.id,
            title: 'Queue Update',
            message: n.message,
            timestamp: new Date(n.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            type: (n.message.includes('proceed') || n.message.includes('RECALL') ? 'called' : 'info') as 'called' | 'info',
            read: n.read,
          }));
          setNotifications(mapped);
        }
      }
    } catch (err) {
      // In case server is loading or offline, fallback to in-memory state
    }
  }, [currentUser, soundEnabled]);

  // Initial load and SSE real-time listener
  useEffect(() => {
    refreshData();

    // Setup Server-Sent Events (SSE) connection for instant push updates
    let eventSource: EventSource | null = null;
    try {
      eventSource = new EventSource('/api/events');
      eventSource.onmessage = () => {
        refreshData();
      };
      eventSource.addEventListener('update', () => {
        refreshData();
      });
    } catch {
      // Fallback to polling
    }

    // Interval polling every 3 seconds as resilient backup
    const interval = setInterval(() => {
      refreshData();
    }, 3000);

    return () => {
      clearInterval(interval);
      if (eventSource) eventSource.close();
      chimeSynthesizer.stopTabAlert();
    };
  }, [refreshData]);

  // Sync current user to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(currentUser));
    } catch { /* ignore */ }
  }, [currentUser]);

  // Sync sound setting to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_SOUND, JSON.stringify(soundEnabled));
    } catch { /* ignore */ }
  }, [soundEnabled]);

  // Helper: Count people ahead
  const getPeopleAhead = useCallback((tokenId: string): number => {
    const targetToken = tokens.find(t => t.id === tokenId);
    if (!targetToken || targetToken.status !== 'WAITING') return 0;

    const targetTime = new Date(targetToken.created_at).getTime();
    return tokens.filter(t => 
      t.service_id === targetToken.service_id &&
      t.status === 'WAITING' &&
      new Date(t.created_at).getTime() < targetTime
    ).length;
  }, [tokens]);

  // Helper: Estimate waiting minutes: number of people ahead × average service time
  const getEstimatedWait = useCallback((tokenId: string): number => {
    const targetToken = tokens.find(t => t.id === tokenId);
    if (!targetToken || targetToken.status !== 'WAITING') return 0;

    const peopleAhead = getPeopleAhead(tokenId);
    const service = services.find(s => s.id === targetToken.service_id);
    const avgDuration = service ? service.average_service_time : 5;

    return Math.max(2, (peopleAhead + 1) * avgDuration);
  }, [tokens, services, getPeopleAhead]);

  // Helper: Current serving token for a service
  const getCurrentServingTokenForService = useCallback((serviceId: string): Token | null => {
    const serving = tokens.find(t => 
      t.service_id === serviceId && 
      (t.status === 'SERVING' || t.status === 'CALLED')
    );
    return serving || null;
  }, [tokens]);

  // Helper: Current user active token
  const getUserActiveToken = useCallback((): Token | null => {
    const active = tokens.find(t => 
      t.user_id === currentUser.id && 
      (t.status === 'WAITING' || t.status === 'CALLED' || t.status === 'SERVING')
    );
    return active || null;
  }, [tokens, currentUser.id]);

  // Generate Token (POST /api/tokens)
  const generateToken = useCallback(async (serviceId: string, customName?: string): Promise<Token> => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/tokens', {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          serviceId,
          userName: customName || currentUser.name,
          userId: currentUser.id,
        }),
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.error || 'Failed to generate token');
      }

      const backendToken = await res.json();
      const mapped = mapBackendToken(backendToken);
      
      setTokens(prev => [...prev.filter(t => t.id !== mapped.id), mapped]);
      await refreshData();
      return mapped;
    } finally {
      setIsLoading(false);
    }
  }, [currentUser, getAuthHeaders, refreshData]);

  // Admin: Call Next Token (PUT /api/tokens/call-next)
  const callNextToken = useCallback(async (preferredCounterId?: string, preferredServiceId?: string): Promise<Token | null> => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/tokens/call-next', {
        method: 'PUT',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          counterId: preferredCounterId,
          serviceId: preferredServiceId,
        }),
      });

      if (!res.ok) {
        return null;
      }

      const data = await res.json();
      const calledToken = mapBackendToken(data.token);
      setLastCalledToken(calledToken);

      if (soundEnabled) {
        chimeSynthesizer.playCalledDing();
      }

      await refreshData();
      return calledToken;
    } finally {
      setIsLoading(false);
    }
  }, [getAuthHeaders, soundEnabled, refreshData]);

  // Admin: Recall Token (PUT /api/tokens/:id/recall)
  const recallToken = useCallback(async (tokenId: string) => {
    try {
      const res = await fetch(`/api/tokens/${tokenId}/recall`, {
        method: 'PUT',
        headers: getAuthHeaders(),
      });
      if (res.ok) {
        const data = await res.json();
        const mapped = mapBackendToken(data);
        setLastCalledToken(mapped);
        if (soundEnabled) {
          chimeSynthesizer.playCalledDing();
        }
        await refreshData();
      }
    } catch { /* handle */ }
  }, [getAuthHeaders, soundEnabled, refreshData]);

  // Admin: Mark Serving (PUT /api/tokens/:id/serve)
  const serveToken = useCallback(async (tokenId: string) => {
    try {
      setTokens(prev => prev.map(t => t.id === tokenId ? { ...t, status: 'SERVING' } : t));
    } catch { /* handle */ }
  }, []);

  // Admin: Complete Token (PUT /api/tokens/:id/complete)
  const completeToken = useCallback(async (tokenId: string) => {
    try {
      const res = await fetch(`/api/tokens/${tokenId}/complete`, {
        method: 'PUT',
        headers: getAuthHeaders(),
      });
      if (res.ok) {
        chimeSynthesizer.stopTabAlert();
        await refreshData();
      }
    } catch { /* handle */ }
  }, [getAuthHeaders, refreshData]);

  // Admin: Skip Token (PUT /api/tokens/:id/skip)
  const skipToken = useCallback(async (tokenId: string) => {
    try {
      const res = await fetch(`/api/tokens/${tokenId}/skip`, {
        method: 'PUT',
        headers: getAuthHeaders(),
      });
      if (res.ok) {
        chimeSynthesizer.stopTabAlert();
        await refreshData();
      }
    } catch { /* handle */ }
  }, [getAuthHeaders, refreshData]);

  // Admin: Hold Token
  const holdToken = useCallback(async (tokenId: string) => {
    try {
      await fetch(`/api/tokens/${tokenId}/hold`, {
        method: 'PUT',
        headers: getAuthHeaders(),
      });
      await refreshData();
    } catch { /* handle */ }
  }, [getAuthHeaders, refreshData]);

  // Admin: Transfer Token
  const transferToken = useCallback(async (tokenId: string, targetServiceId: string) => {
    try {
      await fetch(`/api/tokens/${tokenId}/transfer`, {
        method: 'PUT',
        headers: getAuthHeaders(),
        body: JSON.stringify({ targetServiceId }),
      });
      await refreshData();
    } catch { /* handle */ }
  }, [getAuthHeaders, refreshData]);

  // Cancel Token (PUT /api/tokens/:id/cancel)
  const cancelToken = useCallback(async (tokenId: string) => {
    try {
      const res = await fetch(`/api/tokens/${tokenId}/cancel`, {
        method: 'PUT',
        headers: getAuthHeaders(),
      });
      if (res.ok) {
        chimeSynthesizer.stopTabAlert();
        await refreshData();
      }
    } catch { /* handle */ }
  }, [getAuthHeaders, refreshData]);

  // Reset Queue
  const resetQueue = useCallback(async () => {
    try {
      await fetch('/api/queue/reset', {
        method: 'POST',
        headers: getAuthHeaders(),
      });
      setLastCalledToken(null);
      chimeSynthesizer.stopTabAlert();
      await refreshData();
    } catch { /* handle */ }
  }, [getAuthHeaders, refreshData]);

  // Services CRUD
  const addService = useCallback(async (srv: Omit<Service, 'id'>) => {
    try {
      await fetch('/api/services', {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          name: srv.name,
          prefix: srv.code,
          description: srv.description,
          averageServiceTime: srv.average_service_time,
        }),
      });
      await refreshData();
    } catch { /* handle */ }
  }, [getAuthHeaders, refreshData]);

  const updateService = useCallback(async (id: string, updates: Partial<Service>) => {
    try {
      await fetch(`/api/services/${id}`, {
        method: 'PUT',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          name: updates.name,
          prefix: updates.code,
          description: updates.description,
          averageServiceTime: updates.average_service_time,
          status: updates.status ? (updates.status === 'active' ? 'ACTIVE' : 'INACTIVE') : undefined,
        }),
      });
      await refreshData();
    } catch { /* handle */ }
  }, [getAuthHeaders, refreshData]);

  const deleteService = useCallback(async (id: string) => {
    try {
      await fetch(`/api/services/${id}`, {
        method: 'DELETE',
        headers: getAuthHeaders(),
      });
      await refreshData();
    } catch { /* handle */ }
  }, [getAuthHeaders, refreshData]);

  // Counters CRUD
  const addCounter = useCallback(async (cnt: Omit<Counter, 'id'>) => {
    try {
      await fetch('/api/counters', {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          counterNumber: cnt.counter_number,
          assignedStaff: cnt.staff_name,
          serviceId: cnt.assigned_service_ids[0] || 'srv-student',
          status: cnt.status?.toUpperCase() || 'AVAILABLE',
        }),
      });
      await refreshData();
    } catch { /* handle */ }
  }, [getAuthHeaders, refreshData]);

  const updateCounter = useCallback(async (id: string, updates: Partial<Counter>) => {
    try {
      await fetch(`/api/counters/${id}`, {
        method: 'PUT',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          counterNumber: updates.counter_number,
          assignedStaff: updates.staff_name,
          serviceId: updates.assigned_service_ids ? updates.assigned_service_ids[0] : undefined,
          status: updates.status?.toUpperCase(),
        }),
      });
      await refreshData();
    } catch { /* handle */ }
  }, [getAuthHeaders, refreshData]);

  const updateCounterStatus = useCallback(async (id: string, status: CounterStatus) => {
    try {
      await fetch(`/api/counters/${id}`, {
        method: 'PUT',
        headers: getAuthHeaders(),
        body: JSON.stringify({ status: status.toUpperCase() }),
      });
      await refreshData();
    } catch { /* handle */ }
  }, [getAuthHeaders, refreshData]);

  // Authentication Flows
  const loginAs = useCallback(async (role: 'user' | 'admin' | 'staff') => {
    const email = role === 'admin' ? 'admin@smartqueue.ac.in' : 'alex.morgan@university.edu';
    const password = role === 'admin' ? 'admin123' : 'student123';

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      if (res.ok) {
        const data = await res.json();
        const loggedUser: User = {
          id: data.user.uid,
          name: data.user.name,
          email: data.user.email,
          role: data.user.role === 'ADMIN' ? 'admin' : 'user',
          studentId: data.user.role === 'ADMIN' ? 'FAC-HEAD-01' : 'STU-2024-882',
        };
        localStorage.setItem(STORAGE_KEY_TOKEN, data.token);
        setCurrentUser(loggedUser);
        await refreshData();
      }
    } catch {
      // Offline fallback
      if (role === 'admin') {
        setCurrentUser(INITIAL_USERS[1]);
      } else {
        setCurrentUser(INITIAL_USERS[0]);
      }
    }
  }, [refreshData]);

  const loginWithEmail = useCallback(async (email: string, password: string = 'demo1234'): Promise<{ success: boolean; error?: string }> => {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Authentication failed' };
      }

      const loggedUser: User = {
        id: data.user.uid,
        name: data.user.name,
        email: data.user.email,
        role: data.user.role === 'ADMIN' ? 'admin' : 'user',
        studentId: data.user.studentId || 'STU-' + Math.floor(1000 + Math.random() * 9000),
      };

      localStorage.setItem(STORAGE_KEY_TOKEN, data.token);
      setCurrentUser(loggedUser);
      await refreshData();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error connecting to backend' };
    }
  }, [refreshData]);

  const registerUser = useCallback(async (
    name: string, 
    email: string, 
    studentId?: string, 
    password: string = 'student123'
  ): Promise<{ success: boolean; error?: string; user?: User }> => {
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password, role: 'USER' }),
      });

      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Registration failed' };
      }

      const newUser: User = {
        id: data.user.uid,
        name: data.user.name,
        email: data.user.email,
        role: 'user',
        studentId: studentId || 'STU-' + Math.floor(1000 + Math.random() * 9000),
      };

      localStorage.setItem(STORAGE_KEY_TOKEN, data.token);
      setCurrentUser(newUser);
      await refreshData();
      return { success: true, user: newUser };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error during registration' };
    }
  }, [refreshData]);

  const forgotPassword = useCallback(async (email: string) => {
    try {
      const res = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Password reset request failed' };
      }
      return { success: true, message: data.message };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error' };
    }
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem(STORAGE_KEY_TOKEN);
    setCurrentUser(INITIAL_USERS[0]);
    chimeSynthesizer.stopTabAlert();
  }, []);

  const toggleSound = useCallback((): boolean => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    if (next) {
      chimeSynthesizer.playCalledDing();
    }
    return next;
  }, [soundEnabled]);

  const dismissNotification = useCallback((id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  const clearNotifications = useCallback(() => {
    setNotifications([]);
  }, []);

  // Metrics
  const getMetrics = useCallback((): QueueMetric => {
    const waitingCount = tokens.filter(t => t.status === 'WAITING').length;
    const servingCount = tokens.filter(t => t.status === 'SERVING' || t.status === 'CALLED').length;
    const servedTodayCount = tokens.filter(t => t.status === 'COMPLETED').length;
    
    const completedTokens = tokens.filter(t => t.status === 'COMPLETED' && t.called_at);
    let totalWaitMin = 0;
    if (completedTokens.length > 0) {
      completedTokens.forEach(t => {
        const wait = (new Date(t.called_at!).getTime() - new Date(t.created_at).getTime()) / (1000 * 60);
        totalWaitMin += Math.max(1, wait);
      });
      totalWaitMin = Math.round(totalWaitMin / completedTokens.length);
    } else {
      totalWaitMin = 14;
    }

    return {
      waitingCount,
      servingCount,
      servedTodayCount,
      avgWaitMinutes: totalWaitMin,
    };
  }, [tokens]);

  const value = useMemo(() => ({
    services,
    counters,
    tokens,
    currentUser,
    users,
    notifications,
    toasts,
    soundEnabled,
    lastCalledToken,
    isLoading,
    showToast,
    dismissToast,
    playCalledNotificationSound: (tokenId?: string) => webAudioQueueNotifier.notifyCalledOnce(tokenId || 'manual'),
    generateToken,
    callNextToken,
    recallToken,
    serveToken,
    completeToken,
    skipToken,
    holdToken,
    transferToken,
    cancelToken,
    resetQueue,
    addService,
    updateService,
    deleteService,
    addCounter,
    updateCounter,
    updateCounterStatus,
    setCurrentUser,
    loginAs,
    loginWithEmail,
    registerUser,
    forgotPassword,
    logout,
    toggleSound,
    dismissNotification,
    clearNotifications,
    getPeopleAhead,
    getEstimatedWait,
    getCurrentServingTokenForService,
    getUserActiveToken,
    getMetrics,
  }), [
    services,
    counters,
    tokens,
    currentUser,
    users,
    notifications,
    soundEnabled,
    lastCalledToken,
    isLoading,
    generateToken,
    callNextToken,
    recallToken,
    serveToken,
    completeToken,
    skipToken,
    holdToken,
    transferToken,
    cancelToken,
    resetQueue,
    addService,
    updateService,
    deleteService,
    addCounter,
    updateCounter,
    updateCounterStatus,
    loginAs,
    loginWithEmail,
    registerUser,
    forgotPassword,
    logout,
    toggleSound,
    dismissNotification,
    clearNotifications,
    getPeopleAhead,
    getEstimatedWait,
    getCurrentServingTokenForService,
    getUserActiveToken,
    getMetrics,
  ]);

  return (
    <QueueContext.Provider value={value}>
      {children}
    </QueueContext.Provider>
  );
};

export const useQueue = () => {
  const context = useContext(QueueContext);
  if (!context) {
    throw new Error('useQueue must be used within a QueueProvider');
  }
  return context;
};
