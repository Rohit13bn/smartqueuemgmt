/**
 * Web Audio API synthesizer for queue notification chimes
 * Alerts users with an unmistakable yet pleasant acoustic 'ding' even when looking away from the screen.
 */

class SoundSynthesizer {
  private ctx: AudioContext | null = null;
  private isUnlocked: boolean = false;
  private titleInterval: number | null = null;
  private originalTitle: string = '';

  constructor() {
    if (typeof window !== 'undefined') {
      this.originalTitle = document.title;
      // Auto-unlock AudioContext on first user interaction anywhere on the page
      const unlockAudio = () => {
        const ctx = this.getContext();
        if (ctx && ctx.state === 'suspended') {
          ctx.resume().then(() => {
            this.isUnlocked = true;
          });
        } else if (ctx) {
          this.isUnlocked = true;
        }
        window.removeEventListener('click', unlockAudio);
        window.removeEventListener('touchstart', unlockAudio);
        window.removeEventListener('keydown', unlockAudio);
      };

      window.addEventListener('click', unlockAudio, { once: false });
      window.addEventListener('touchstart', unlockAudio, { once: false });
      window.addEventListener('keydown', unlockAudio, { once: false });
    }
  }

  private getContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  /**
   * Subtle high-clarity bell 'ding' sound specifically for 'CALLED' status
   * Engineered with dual harmonic sine waves (fundamental 987.77 Hz B5 + overtone 1975.53 Hz B6)
   * to ensure acoustic salience even when user is looking away or tab is backgrounded.
   */
  public playCalledDing() {
    try {
      const ctx = this.getContext();
      if (!ctx) return;

      const now = ctx.currentTime;

      // Primary crystalline fundamental tone (B5 ~ 987.77 Hz)
      const osc1 = ctx.createOscillator();
      const gain1 = ctx.createGain();
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(987.77, now);

      gain1.gain.setValueAtTime(0, now);
      gain1.gain.linearRampToValueAtTime(0.35, now + 0.012); // Instant crisp attack
      gain1.gain.exponentialRampToValueAtTime(0.001, now + 1.25); // Resonant gentle ring-out

      osc1.connect(gain1);
      gain1.connect(ctx.destination);

      osc1.start(now);
      osc1.stop(now + 1.3);

      // Shimmering harmonic overtone (B6 ~ 1975.53 Hz)
      const osc2 = ctx.createOscillator();
      const gain2 = ctx.createGain();
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(1975.53, now);

      gain2.gain.setValueAtTime(0, now);
      gain2.gain.linearRampToValueAtTime(0.18, now + 0.008);
      gain2.gain.exponentialRampToValueAtTime(0.0005, now + 0.85);

      osc2.connect(gain2);
      gain2.connect(ctx.destination);

      osc2.start(now);
      osc2.stop(now + 0.9);
    } catch (e) {
      console.warn('Audio ding playback could not proceed:', e);
    }
  }

  /**
   * Two-tone airport/counter chime
   */
  public playCallChime() {
    try {
      const ctx = this.getContext();
      if (!ctx) return;

      const now = ctx.currentTime;

      // Tone 1: E5 (659.25 Hz)
      const osc1 = ctx.createOscillator();
      const gain1 = ctx.createGain();
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(659.25, now);
      gain1.gain.setValueAtTime(0, now);
      gain1.gain.linearRampToValueAtTime(0.25, now + 0.05);
      gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.55);
      osc1.connect(gain1);
      gain1.connect(ctx.destination);
      osc1.start(now);
      osc1.stop(now + 0.6);

      // Tone 2: A5 (880 Hz)
      const osc2 = ctx.createOscillator();
      const gain2 = ctx.createGain();
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(880.0, now + 0.35);
      gain2.gain.setValueAtTime(0, now + 0.35);
      gain2.gain.linearRampToValueAtTime(0.3, now + 0.4);
      gain2.gain.exponentialRampToValueAtTime(0.001, now + 1.1);
      osc2.connect(gain2);
      gain2.connect(ctx.destination);
      osc2.start(now + 0.35);
      osc2.stop(now + 1.2);
    } catch {
      // Audio autoplay policy fallback
    }
  }

  /**
   * Subtle alert ding for turn approaching
   */
  public playApproachingDing() {
    try {
      const ctx = this.getContext();
      if (!ctx) return;

      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(587.33, now); // D5
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.2); // Ramp to A5

      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.45);
    } catch {
      // Ignore audio error
    }
  }

  /**
   * Flash browser document tab title when user is looking away
   */
  public startTabAlert(tokenNumber: string, counterNumber?: string) {
    if (typeof window === 'undefined') return;
    this.stopTabAlert();

    const text1 = `🔔 [CALL: ${tokenNumber}]`;
    const text2 = counterNumber ? `➡️ Proceed to ${counterNumber}` : `➡️ It's Your Turn!`;
    let toggle = false;

    this.titleInterval = window.setInterval(() => {
      document.title = toggle ? text1 : text2;
      toggle = !toggle;
    }, 1000);

    // Also attempt native system notification if permitted
    try {
      if ('Notification' in window && Notification.permission === 'granted') {
        new Notification(`SmartQueue Turn Called: ${tokenNumber}`, {
          body: `Please proceed immediately to ${counterNumber || 'the service counter'}.`,
          icon: '/favicon.ico',
        });
      } else if ('Notification' in window && Notification.permission === 'default') {
        Notification.requestPermission().catch(() => {});
      }
    } catch {
      // Notification API fallback
    }
  }

  public stopTabAlert() {
    if (this.titleInterval !== null) {
      clearInterval(this.titleInterval);
      this.titleInterval = null;
      if (this.originalTitle) {
        document.title = this.originalTitle;
      }
    }
  }
}

export const chimeSynthesizer = new SoundSynthesizer();
