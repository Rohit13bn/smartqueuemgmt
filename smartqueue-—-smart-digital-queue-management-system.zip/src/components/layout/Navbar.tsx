import React, { useState } from 'react';
import { 
  Layers, 
  Volume2, 
  VolumeX, 
  Bell, 
  Tv, 
  Ticket, 
  LayoutDashboard, 
  ShieldCheck, 
  LogOut, 
  User as UserIcon,
  ChevronDown,
  Menu,
  X,
  Clock,
  Sparkles,
  MapPin,
  CheckCircle2,
  Settings
} from 'lucide-react';
import { useQueue } from '../../context/QueueContext';
import { StatusBadge } from '../ui';

interface NavbarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  onOpenAuth: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentView, onNavigate, onOpenAuth }) => {
  const { 
    currentUser, 
    soundEnabled, 
    toggleSound, 
    notifications, 
    dismissNotification, 
    clearNotifications,
    getUserActiveToken,
    logout
  } = useQueue();

  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const activeToken = getUserActiveToken();
  const unreadNotifCount = notifications.filter(n => !n.read).length;

  if (currentView === 'live-display') {
    // Hidden in fullscreen TV mode to maximize viewport
    return null;
  }

  const handleNav = (view: string) => {
    onNavigate(view);
    setMobileMenuOpen(false);
    setShowProfileMenu(false);
    setShowNotifications(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        
        {/* Zone 1: Brand & Branch / Location Indicator */}
        <div className="flex items-center gap-6">
          <button 
            onClick={() => handleNav('landing')}
            className="flex items-center gap-2.5 text-left group focus-visible:outline-none cursor-pointer"
          >
            <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center text-white font-bold shadow-xs shadow-blue-500/20 group-hover:bg-blue-700 transition-colors">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <span className="text-lg font-bold text-slate-900 tracking-tight group-hover:text-blue-600 transition-colors">
                SmartQueue
              </span>
            </div>
          </button>

          {/* Location & System Health Indicator */}
          <div className="hidden xl:flex items-center gap-2 pl-4 border-l border-slate-200 text-xs text-slate-500">
            <span className="flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-slate-400" />
              <span>Central Service Hub</span>
            </span>
            <span className="text-slate-300">·</span>
            <span className="inline-flex items-center gap-1.5 text-emerald-600 font-medium">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span>Operational</span>
            </span>
          </div>

          {/* Quick Active Token Pill (Quiet non-pill banner) */}
          {activeToken && (
            <button
              onClick={() => handleNav('my-queue')}
              className="hidden lg:flex items-center gap-2 text-xs text-slate-600 hover:text-blue-600 px-2.5 py-1 rounded-lg border border-blue-200 bg-blue-50/60 transition-colors cursor-pointer"
            >
              <span className="w-2 h-2 rounded-full bg-blue-600 animate-pulse" />
              <span className="font-semibold text-slate-900 font-mono">{activeToken.token_number}</span>
              <span className="text-slate-400">·</span>
              <span>{activeToken.status === 'CALLED' ? 'Turn Called!' : 'In Queue'}</span>
            </button>
          )}
        </div>

        {/* Zone 2: Desktop Navigation Links */}
        <nav className="hidden md:flex items-center gap-6 lg:gap-8 text-sm font-medium text-slate-600">
          <button 
            onClick={() => handleNav('landing')}
            className={`transition-colors hover:text-slate-900 cursor-pointer ${currentView === 'landing' ? 'text-blue-600 font-semibold' : ''}`}
          >
            Home
          </button>
          <button 
            onClick={() => handleNav('take-token')}
            className={`transition-colors hover:text-slate-900 cursor-pointer ${currentView === 'take-token' ? 'text-blue-600 font-semibold' : ''}`}
          >
            Take Token
          </button>
          <button 
            onClick={() => handleNav('my-queue')}
            className={`transition-colors hover:text-slate-900 cursor-pointer ${currentView === 'my-queue' ? 'text-blue-600 font-semibold' : ''}`}
          >
            My Queue
          </button>
          <button 
            onClick={() => handleNav('live-display')}
            className="flex items-center gap-1.5 transition-colors hover:text-blue-600 text-slate-600 cursor-pointer"
          >
            <Tv className="w-4 h-4 text-slate-400" />
            <span>TV Display</span>
          </button>
          
          {currentUser.role === 'admin' ? (
            <button 
              onClick={() => handleNav('admin-dashboard')}
              className={`transition-colors hover:text-slate-900 cursor-pointer ${currentView.startsWith('admin') ? 'text-blue-600 font-semibold' : ''}`}
            >
              Admin Desk
            </button>
          ) : (
            <button 
              onClick={() => handleNav('user-dashboard')}
              className={`transition-colors hover:text-slate-900 cursor-pointer ${currentView === 'user-dashboard' ? 'text-blue-600 font-semibold' : ''}`}
            >
              Dashboard
            </button>
          )}
        </nav>

        {/* Zone 3: Actions & Profile Menu */}
        <div className="flex items-center gap-2 sm:gap-3">
          
          {/* Sound Chime Toggle */}
          <button
            onClick={toggleSound}
            title={soundEnabled ? 'Chime sound enabled' : 'Chime sound muted'}
            aria-label={soundEnabled ? 'Chime sound enabled' : 'Chime sound muted'}
            className="p-2 rounded-xl text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            {soundEnabled ? (
              <Volume2 className="w-4 h-4 text-blue-600" />
            ) : (
              <VolumeX className="w-4 h-4 text-slate-400" />
            )}
          </button>

          {/* Notifications Dropdown */}
          <div className="relative">
            <button
              onClick={() => {
                setShowNotifications(!showNotifications);
                setShowProfileMenu(false);
              }}
              className="relative p-2 rounded-xl text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-colors cursor-pointer"
              title="Notifications"
              aria-label="View notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadNotifCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-blue-600" />
              )}
            </button>

            {showNotifications && (
              <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden z-50 animate-in fade-in zoom-in-95 duration-150">
                <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between bg-slate-50">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">Queue Alerts</span>
                    {unreadNotifCount > 0 && (
                      <span className="px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-700">
                        {unreadNotifCount} new
                      </span>
                    )}
                  </div>
                  {notifications.length > 0 && (
                    <button 
                      onClick={clearNotifications}
                      className="text-xs text-slate-500 hover:text-slate-800 cursor-pointer"
                    >
                      Clear all
                    </button>
                  )}
                </div>
                
                <div className="max-h-80 overflow-y-auto divide-y divide-slate-100">
                  {notifications.length === 0 ? (
                    <div className="p-8 text-center text-xs text-slate-500">
                      No notifications yet
                    </div>
                  ) : (
                    notifications.map(n => (
                      <div key={n.id} className="p-3.5 hover:bg-slate-50 transition-colors flex items-start gap-3">
                        <div className={`mt-0.5 w-2 h-2 rounded-full shrink-0 ${
                          n.type === 'called' ? 'bg-emerald-600 animate-ping' :
                          n.type === 'approaching' ? 'bg-amber-500' : 'bg-blue-600'
                        }`} />
                        <div className="flex-1 min-w-0">
                          <div className="text-xs font-semibold text-slate-900 flex items-center justify-between">
                            <span>{n.title}</span>
                            <span className="text-[10px] text-slate-400 font-normal">{n.timestamp}</span>
                          </div>
                          <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">{n.message}</p>
                        </div>
                        <button 
                          onClick={() => dismissNotification(n.id)}
                          className="text-slate-300 hover:text-slate-600 text-xs shrink-0 cursor-pointer"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          {/* User Profile Dropdown */}
          <div className="relative">
            <button
              onClick={() => {
                setShowProfileMenu(!showProfileMenu);
                setShowNotifications(false);
              }}
              className="flex items-center gap-2 pl-2 pr-3 py-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 transition-colors text-xs font-medium text-slate-700 cursor-pointer"
            >
              <div className="w-7 h-7 rounded-lg bg-blue-100 text-blue-700 font-bold flex items-center justify-center text-xs">
                {currentUser.name.slice(0, 2).toUpperCase()}
              </div>
              <div className="text-left hidden sm:block">
                <span className="block font-semibold text-slate-900 truncate max-w-[110px]">{currentUser.name}</span>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {showProfileMenu && (
              <div className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-xl border border-slate-200 p-2 z-50 animate-in fade-in zoom-in-95 duration-150">
                <div className="px-3 py-2.5 border-b border-slate-100 mb-1">
                  <div className="font-bold text-xs text-slate-900">{currentUser.name}</div>
                  <div className="text-[11px] text-slate-500 font-mono truncate">{currentUser.email}</div>
                  <div className="mt-1.5 flex items-center gap-1.5">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                      currentUser.role === 'admin' ? 'bg-purple-50 text-purple-700 border border-purple-200' : 'bg-blue-50 text-blue-700 border border-blue-200'
                    }`}>
                      {currentUser.role === 'admin' ? 'Administrator' : 'User Account'}
                    </span>
                  </div>
                </div>

                <div className="space-y-0.5">
                  <button
                    onClick={() => handleNav(currentUser.role === 'admin' ? 'admin-dashboard' : 'user-dashboard')}
                    className="w-full text-left px-3 py-2 rounded-xl text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2 cursor-pointer"
                  >
                    <LayoutDashboard className="w-3.5 h-3.5 text-slate-400" />
                    <span>{currentUser.role === 'admin' ? 'Admin Console' : 'My Dashboard'}</span>
                  </button>

                  <button
                    onClick={() => handleNav('my-queue')}
                    className="w-full text-left px-3 py-2 rounded-xl text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2 cursor-pointer"
                  >
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    <span>My Active Token</span>
                  </button>

                  <button
                    onClick={() => handleNav('settings')}
                    className="w-full text-left px-3 py-2 rounded-xl text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2 cursor-pointer"
                  >
                    <Settings className="w-3.5 h-3.5 text-slate-400" />
                    <span>Settings & Preferences</span>
                  </button>

                  <button
                    onClick={() => {
                      setShowProfileMenu(false);
                      onOpenAuth();
                    }}
                    className="w-full text-left px-3 py-2 rounded-xl text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2 cursor-pointer"
                  >
                    <UserIcon className="w-3.5 h-3.5 text-slate-400" />
                    <span>Switch or Sign In Account</span>
                  </button>
                </div>

                <div className="border-t border-slate-100 my-1 pt-1">
                  <button
                    onClick={() => {
                      logout();
                      setShowProfileMenu(false);
                      onNavigate('landing');
                    }}
                    className="w-full text-left px-3 py-2 rounded-xl text-xs text-rose-600 hover:bg-rose-50 flex items-center gap-2 cursor-pointer font-medium"
                  >
                    <LogOut className="w-3.5 h-3.5 text-rose-500" />
                    <span>Sign Out</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Primary CTA button */}
          <button
            onClick={() => handleNav('take-token')}
            className="hidden sm:inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-xl shadow-xs shadow-blue-500/20 transition-all cursor-pointer"
          >
            <Ticket className="w-3.5 h-3.5" />
            <span>Get Token</span>
          </button>

          {/* Mobile Menu Toggle Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-xl text-slate-600 hover:bg-slate-100 cursor-pointer"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-6 space-y-3 animate-in slide-in-from-top-2 duration-150">
          <div className="space-y-1">
            <button
              onClick={() => handleNav('landing')}
              className={`w-full text-left px-3 py-2 rounded-xl text-sm font-medium ${currentView === 'landing' ? 'bg-blue-50 text-blue-700' : 'text-slate-700'}`}
            >
              Home
            </button>
            <button
              onClick={() => handleNav('take-token')}
              className={`w-full text-left px-3 py-2 rounded-xl text-sm font-medium ${currentView === 'take-token' ? 'bg-blue-50 text-blue-700' : 'text-slate-700'}`}
            >
              Take Digital Token
            </button>
            <button
              onClick={() => handleNav('my-queue')}
              className={`w-full text-left px-3 py-2 rounded-xl text-sm font-medium ${currentView === 'my-queue' ? 'bg-blue-50 text-blue-700' : 'text-slate-700'}`}
            >
              My Queue Status
            </button>
            <button
              onClick={() => handleNav('live-display')}
              className="w-full text-left px-3 py-2 rounded-xl text-sm font-medium text-slate-700"
            >
              Live TV Board Display
            </button>
            <button
              onClick={() => handleNav(currentUser.role === 'admin' ? 'admin-dashboard' : 'user-dashboard')}
              className={`w-full text-left px-3 py-2 rounded-xl text-sm font-medium ${currentView === 'user-dashboard' || currentView === 'admin-dashboard' ? 'bg-blue-50 text-blue-700' : 'text-slate-700'}`}
            >
              {currentUser.role === 'admin' ? 'Admin Desk Console' : 'User Dashboard'}
            </button>
            <button
              onClick={() => handleNav('settings')}
              className="w-full text-left px-3 py-2 rounded-xl text-sm font-medium text-slate-700"
            >
              Settings & Preferences
            </button>
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenAuth();
              }}
              className="text-xs text-blue-600 font-semibold"
            >
              Switch Account
            </button>
            <button
              onClick={() => handleNav('take-token')}
              className="px-4 py-2 bg-blue-600 text-white rounded-xl text-xs font-semibold shadow-xs"
            >
              Get Token
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
