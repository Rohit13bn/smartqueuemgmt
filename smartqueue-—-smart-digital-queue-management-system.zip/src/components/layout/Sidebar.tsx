import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  Ticket, 
  Tv, 
  Layers, 
  Monitor, 
  BarChart3, 
  Settings, 
  Clock, 
  CheckCircle2, 
  ShieldCheck,
  User as UserIcon,
  ChevronLeft,
  ChevronRight,
  Activity,
  Flame,
  Users
} from 'lucide-react';
import { useQueue } from '../../context/QueueContext';

interface SidebarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  isAdminMode?: boolean;
}

interface NavSection {
  title: string;
  items: {
    id: string;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: number;
  }[];
}

export const Sidebar: React.FC<SidebarProps> = ({ currentView, onNavigate, isAdminMode }) => {
  const { currentUser, getMetrics, counters, tokens } = useQueue();
  const metrics = getMetrics();
  const [collapsed, setCollapsed] = useState(false);

  const userSections: NavSection[] = [
    {
      title: 'Self Service',
      items: [
        { id: 'user-dashboard', label: 'My Dashboard', icon: LayoutDashboard },
        { id: 'take-token', label: 'Take Digital Token', icon: Ticket },
        { id: 'my-queue', label: 'Live Queue Turn', icon: Clock },
      ]
    },
    {
      title: 'Public Displays',
      items: [
        { id: 'live-display', label: 'Live TV Board', icon: Tv },
      ]
    },
    {
      title: 'Account',
      items: [
        { id: 'settings', label: 'Preferences', icon: Settings },
      ]
    }
  ];

  const adminSections: NavSection[] = [
    {
      title: 'Desk Operations',
      items: [
        { id: 'admin-dashboard', label: 'Queue Operations', icon: LayoutDashboard, badge: metrics.waitingCount },
        { id: 'counter-management', label: 'Counters & Desks', icon: Monitor },
        { id: 'service-management', label: 'Service Catalog', icon: Layers },
      ]
    },
    {
      title: 'Intelligence',
      items: [
        { id: 'analytics', label: 'Queue Analytics', icon: BarChart3 },
        { id: 'live-display', label: 'Launch TV Display', icon: Tv },
      ]
    },
    {
      title: 'System',
      items: [
        { id: 'settings', label: 'System Settings', icon: Settings },
      ]
    }
  ];

  const sections = isAdminMode ? adminSections : userSections;

  return (
    <aside 
      className={`${
        collapsed ? 'w-20' : 'w-64'
      } shrink-0 border-r border-slate-200 bg-white flex flex-col justify-between h-[calc(100vh-4rem)] sticky top-16 transition-all duration-200 select-none`}
    >
      <div className="p-3.5 space-y-5 overflow-y-auto">
        
        {/* Context Portal Header & Collapse Toggle */}
        <div className={`px-3 py-2.5 bg-slate-50 rounded-xl border border-slate-200/60 flex items-center ${collapsed ? 'justify-center' : 'justify-between'}`}>
          <div className="flex items-center gap-2.5 min-w-0">
            {isAdminMode ? (
              <div className="w-6 h-6 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center shrink-0">
                <ShieldCheck className="w-3.5 h-3.5" />
              </div>
            ) : (
              <div className="w-6 h-6 rounded-lg bg-slate-200 text-slate-700 flex items-center justify-center shrink-0">
                <UserIcon className="w-3.5 h-3.5" />
              </div>
            )}
            {!collapsed && (
              <div className="truncate">
                <div className="text-xs font-bold text-slate-900 truncate">
                  {isAdminMode ? 'Admin Command' : 'Student Portal'}
                </div>
                <div className="text-[10px] text-slate-500 font-mono">
                  {isAdminMode ? 'Desk Operations' : 'Active Session'}
                </div>
              </div>
            )}
          </div>

          <button
            onClick={() => setCollapsed(!collapsed)}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200/50 cursor-pointer hidden lg:block"
            title={collapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
          >
            {collapsed ? <ChevronRight className="w-3.5 h-3.5" /> : <ChevronLeft className="w-3.5 h-3.5" />}
          </button>
        </div>

        {/* Section Navigation Groups */}
        <div className="space-y-4">
          {sections.map((section, idx) => (
            <div key={idx} className="space-y-1">
              {!collapsed && (
                <div className="px-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                  {section.title}
                </div>
              )}
              {section.items.map((item) => {
                const Icon = item.icon;
                const isActive = currentView === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => onNavigate(item.id)}
                    title={collapsed ? item.label : undefined}
                    className={`w-full flex items-center ${collapsed ? 'justify-center' : 'justify-between'} px-3 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                      isActive 
                        ? 'bg-blue-600 text-white shadow-xs shadow-blue-500/20' 
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                      {!collapsed && <span className="truncate">{item.label}</span>}
                    </div>

                    {!collapsed && item.badge !== undefined && item.badge > 0 && (
                      <span className={`text-[10px] font-mono font-bold px-1.5 py-0.2 rounded-full ${
                        isActive ? 'bg-blue-700 text-white' : 'bg-blue-50 text-blue-700 border border-blue-200'
                      }`}>
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          ))}
        </div>

        {/* Compact Queue Health Indicator Widget */}
        {!collapsed && (
          <div className="pt-3 border-t border-slate-100">
            <div className="px-3 mb-2 flex items-center justify-between">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Live Dispatch
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            </div>

            <div className="grid grid-cols-2 gap-2 px-1">
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/60">
                <span className="text-[10px] text-slate-500 block">Waiting</span>
                <span className="text-base font-bold font-mono text-slate-900 tabular-nums">
                  {metrics.waitingCount}
                </span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/60">
                <span className="text-[10px] text-slate-500 block">Serving</span>
                <span className="text-base font-bold font-mono text-blue-600 tabular-nums">
                  {metrics.servingCount}
                </span>
              </div>
            </div>
          </div>
        )}

      </div>

      {/* Footer Branding & Status */}
      <div className="p-3 border-t border-slate-100">
        <div className={`px-2 py-1 text-[11px] text-slate-400 flex items-center ${collapsed ? 'justify-center' : 'justify-between'}`}>
          {!collapsed && <span>SmartQueue Enterprise</span>}
          <span className="inline-flex items-center gap-1 text-[10px] text-emerald-600 font-medium">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            {!collapsed && <span>Online</span>}
          </span>
        </div>
      </div>
    </aside>
  );
};
