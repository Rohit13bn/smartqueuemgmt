import React, { useState } from 'react';
import { Sidebar } from './Sidebar';
import { Menu, X, ChevronRight, Home, Building2 } from 'lucide-react';

interface DashboardLayoutProps {
  currentView: string;
  onNavigate: (view: string) => void;
  title: string;
  subtitle?: string;
  action?: React.ReactNode;
  children: React.ReactNode;
  isAdminMode?: boolean;
}

export const DashboardLayout: React.FC<DashboardLayoutProps> = ({
  currentView,
  onNavigate,
  title,
  subtitle,
  action,
  children,
  isAdminMode = false,
}) => {
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-slate-50 flex">
      {/* Desktop Collapsible Sidebar */}
      <div className="hidden lg:block shrink-0">
        <Sidebar 
          currentView={currentView} 
          onNavigate={onNavigate} 
          isAdminMode={isAdminMode} 
        />
      </div>

      {/* Mobile Drawer */}
      {mobileSidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div 
            className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs transition-opacity"
            onClick={() => setMobileSidebarOpen(false)} 
          />
          <div className="relative w-72 bg-white h-full z-10 shadow-2xl flex flex-col animate-in slide-in-from-left duration-200">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Building2 className="w-4 h-4 text-blue-600" />
                <span className="font-bold text-sm text-slate-900">
                  {isAdminMode ? 'Operations Menu' : 'Services Menu'}
                </span>
              </div>
              <button 
                onClick={() => setMobileSidebarOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 cursor-pointer"
                aria-label="Close navigation"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto">
              <Sidebar 
                currentView={currentView} 
                onNavigate={(view) => {
                  onNavigate(view);
                  setMobileSidebarOpen(false);
                }} 
                isAdminMode={isAdminMode} 
              />
            </div>
          </div>
        </div>
      )}

      {/* Main Workspace Canvas */}
      <main className="flex-1 min-w-0 overflow-y-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
          
          {/* Top Bar Contract: Breadcrumb trail + Actions */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-slate-200">
            <div>
              {/* Breadcrumbs */}
              <nav aria-label="Breadcrumb" className="flex items-center gap-1.5 text-xs text-slate-500 mb-1.5">
                <button 
                  onClick={() => onNavigate('landing')}
                  className="hover:text-slate-800 flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <Home className="w-3.5 h-3.5" />
                  <span>Home</span>
                </button>
                <ChevronRight className="w-3 h-3 text-slate-400" />
                <span className="text-slate-500">
                  {isAdminMode ? 'Operations' : 'Student Services'}
                </span>
                <ChevronRight className="w-3 h-3 text-slate-400" />
                <span className="text-slate-900 font-semibold">
                  {title}
                </span>
              </nav>

              <div className="flex items-center gap-3">
                <button
                  onClick={() => setMobileSidebarOpen(true)}
                  className="lg:hidden p-1.5 -ml-1 text-slate-600 hover:bg-slate-200/80 rounded-xl cursor-pointer"
                  title="Open navigation menu"
                  aria-label="Open navigation menu"
                >
                  <Menu className="w-5 h-5" />
                </button>
                <div>
                  <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
                    {title}
                  </h1>
                  {subtitle && (
                    <p className="text-xs text-slate-500 mt-0.5">
                      {subtitle}
                    </p>
                  )}
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            {action && (
              <div className="flex items-center gap-2 self-start sm:self-auto shrink-0">
                {action}
              </div>
            )}
          </div>

          {/* Children Content */}
          {children}
        </div>
      </main>
    </div>
  );
};
